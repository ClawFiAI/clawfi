const E="clawfi-clanker-overlay",A="https://basescan.org/address/",D="0.3.1";function z(a=48){try{return chrome.runtime.getURL(`icons/icon${a}.png`)}catch{return""}}let u=null,c=null,i=null;function O(a){return`${a.slice(0,6)}...${a.slice(-4)}`}function L(a){const e=Date.now()-a,t=Math.floor(e/6e4);if(t<1)return"just now";if(t<60)return`${t}m ago`;const r=Math.floor(t/60);return r<24?`${r}h ago`:`${Math.floor(r/24)}d ago`}function y(a){return a>=1e9?(a/1e9).toFixed(2)+"B":a>=1e6?(a/1e6).toFixed(2)+"M":a>=1e3?(a/1e3).toFixed(1)+"K":a.toFixed(0)}async function M(a){try{await navigator.clipboard.writeText(a)}catch{const e=document.createElement("textarea");e.value=a,document.body.appendChild(e),e.select(),document.execCommand("copy"),document.body.removeChild(e)}}function S(a){const e={critical:"#FF453A",high:"#FF9F0A",medium:"#FFD60A",low:"#0A84FF"};return e[a]||e.low}function R(a){const e=[{id:"copy-address",label:"Copy Address",icon:"📋",description:"Copy token contract address",type:"copy",value:a.address},{id:"dexscreener",label:"DEXScreener",icon:"📊",description:"View charts and analytics",type:"link",url:`https://dexscreener.com/base/${a.address}`},{id:"uniswap",label:"Swap on Uniswap",icon:"🦄",description:"Trade on Uniswap V3",type:"link",url:`https://app.uniswap.org/swap?chain=base&outputCurrency=${a.address}`},{id:"basescan",label:"View on Basescan",icon:"🔍",description:"Contract & transactions",type:"link",url:`${A}${a.address}`},{id:"gecko",label:"CoinGecko",icon:"🦎",description:"Market data & info",type:"link",url:`https://www.coingecko.com/en/coins/${a.address}`},{id:"defined",label:"Defined.fi",icon:"📈",description:"Advanced analytics",type:"link",url:`https://www.defined.fi/base/${a.address}`}];return a.creator&&e.push({id:"copy-creator",label:"Copy Creator",icon:"👤",description:"Copy creator wallet address",type:"copy",value:a.creator}),e}function I(){return`
    :host {
      all: initial;
      font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', 'SF Pro Text', system-ui, sans-serif;
    }
    
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    
    /* ============================================
       iOS LIQUID GLASS DESIGN TOKENS
       ============================================ */
    
    .clawfi-overlay {
      --glass-bg: rgba(255, 255, 255, 0.08);
      --glass-bg-elevated: rgba(255, 255, 255, 0.12);
      --glass-border: rgba(255, 255, 255, 0.18);
      --glass-blur: 40px;
      --glass-blur-heavy: 60px;
      
      /* iOS System Colors */
      --blue: #0A84FF;
      --green: #30D158;
      --red: #FF453A;
      --orange: #FF9F0A;
      --yellow: #FFD60A;
      --purple: #BF5AF2;
      --teal: #64D2FF;
      --pink: #FF375F;
      
      /* Text colors */
      --text-primary: rgba(255, 255, 255, 0.95);
      --text-secondary: rgba(255, 255, 255, 0.6);
      --text-tertiary: rgba(255, 255, 255, 0.4);
      
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 2147483647;
      font-size: 13px;
      line-height: 1.5;
      -webkit-font-smoothing: antialiased;
    }
    
    /* ============================================
       FLOATING ACTION BUTTON - iOS App Icon Style
       ============================================ */
    
    .clawfi-fab {
      width: 60px;
      height: 60px;
      border-radius: 18px;
      background: linear-gradient(180deg, rgba(10, 132, 255, 0.9) 0%, rgba(10, 100, 200, 0.95) 100%);
      border: 1px solid rgba(255, 255, 255, 0.25);
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 
        0 10px 40px rgba(10, 132, 255, 0.4),
        0 2px 10px rgba(0, 0, 0, 0.2),
        inset 0 1px 0 rgba(255, 255, 255, 0.3);
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      position: relative;
      overflow: hidden;
    }
    
    /* Specular highlight */
    .clawfi-fab::before {
      content: '';
      position: absolute;
      inset: 0;
      background: linear-gradient(180deg, rgba(255,255,255,0.35) 0%, rgba(255,255,255,0.1) 30%, transparent 50%);
      pointer-events: none;
      border-radius: inherit;
    }
    
    .clawfi-fab:hover {
      transform: scale(1.08) translateY(-3px);
      box-shadow: 
        0 16px 50px rgba(10, 132, 255, 0.5),
        0 4px 15px rgba(0, 0, 0, 0.25),
        inset 0 1px 0 rgba(255, 255, 255, 0.35);
    }
    
    .clawfi-fab:active {
      transform: scale(0.98);
    }
    
    .clawfi-fab-icon {
      width: 36px;
      height: 36px;
      position: relative;
      z-index: 1;
      border-radius: 8px;
      object-fit: contain;
    }
    
    .clawfi-fab-icon-emoji {
      font-size: 28px;
      position: relative;
      z-index: 1;
    }
    
    .clawfi-fab-badge {
      position: absolute;
      top: -5px;
      right: -5px;
      min-width: 22px;
      height: 22px;
      border-radius: 11px;
      background: var(--red);
      color: white;
      font-size: 12px;
      font-weight: 600;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 0 6px;
      box-shadow: 0 2px 8px rgba(255, 69, 58, 0.5);
      z-index: 2;
    }
    
    .clawfi-fab-risk {
      animation: pulse-risk 2s ease-in-out infinite;
    }
    
    .clawfi-fab-risk-dot {
      position: absolute;
      top: 4px;
      right: 4px;
      width: 12px;
      height: 12px;
      background: var(--red);
      border-radius: 50%;
      box-shadow: 0 0 12px var(--red);
      z-index: 2;
    }
    
    @keyframes pulse-risk {
      0%, 100% { box-shadow: 0 10px 40px rgba(255, 69, 58, 0.3); }
      50% { box-shadow: 0 10px 50px rgba(255, 69, 58, 0.5); }
    }
    
    /* ============================================
       PANEL - iOS Sheet Style
       ============================================ */
    
    .clawfi-panel {
      width: 380px;
      background: rgba(30, 30, 40, 0.75);
      backdrop-filter: blur(var(--glass-blur-heavy)) saturate(200%);
      -webkit-backdrop-filter: blur(var(--glass-blur-heavy)) saturate(200%);
      border-radius: 24px;
      border: 1px solid var(--glass-border);
      box-shadow: 
        0 25px 80px rgba(0, 0, 0, 0.5),
        0 10px 30px rgba(0, 0, 0, 0.3),
        inset 0 1px 0 rgba(255, 255, 255, 0.08);
      overflow: hidden;
      animation: slideIn 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    @keyframes slideIn {
      from {
        opacity: 0;
        transform: translateY(-10px) scale(0.98);
      }
      to {
        opacity: 1;
        transform: translateY(0) scale(1);
      }
    }
    
    /* ============================================
       HEADER - iOS Navigation Bar Style
       ============================================ */
    
    .clawfi-header {
      padding: 18px 20px;
      background: linear-gradient(180deg, rgba(10, 132, 255, 0.85) 0%, rgba(10, 100, 200, 0.9) 100%);
      display: flex;
      align-items: center;
      justify-content: space-between;
      position: relative;
      border-bottom: 1px solid rgba(255, 255, 255, 0.15);
    }
    
    /* Specular highlight on header */
    .clawfi-header::before {
      content: '';
      position: absolute;
      inset: 0;
      background: linear-gradient(180deg, rgba(255,255,255,0.3) 0%, rgba(255,255,255,0.08) 40%, transparent 70%);
      pointer-events: none;
    }
    
    .clawfi-header-title {
      font-weight: 600;
      color: white;
      font-size: 17px;
      display: flex;
      align-items: center;
    }
    
    .clawfi-header-logo {
      width: 24px;
      height: 24px;
      border-radius: 6px;
      object-fit: contain;
      gap: 10px;
      position: relative;
      z-index: 1;
      letter-spacing: -0.3px;
    }
    
    .clawfi-header-actions {
      display: flex;
      gap: 10px;
      position: relative;
      z-index: 1;
    }
    
    .clawfi-header-btn {
      background: rgba(255, 255, 255, 0.2);
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.25);
      color: white;
      width: 32px;
      height: 32px;
      border-radius: 10px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      transition: all 0.2s ease;
    }
    
    .clawfi-header-btn:hover {
      background: rgba(255, 255, 255, 0.3);
      transform: scale(1.05);
    }
    
    /* ============================================
       TAB BAR - iOS Segmented Control
       ============================================ */
    
    .clawfi-tabs {
      display: flex;
      padding: 12px 16px;
      gap: 8px;
      background: rgba(0, 0, 0, 0.2);
      border-bottom: 1px solid rgba(255, 255, 255, 0.06);
    }
    
    .clawfi-tab {
      flex: 1;
      padding: 10px 12px;
      border-radius: 10px;
      border: 1px solid transparent;
      background: transparent;
      color: var(--text-secondary);
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
    }
    
    .clawfi-tab:hover {
      background: rgba(255, 255, 255, 0.05);
    }
    
    .clawfi-tab.active {
      background: rgba(10, 132, 255, 0.3);
      color: white;
      border-color: rgba(10, 132, 255, 0.5);
    }
    
    .clawfi-tab-icon {
      font-size: 14px;
    }
    
    .clawfi-tab-badge {
      background: var(--red);
      color: white;
      font-size: 10px;
      padding: 2px 6px;
      border-radius: 10px;
      font-weight: 600;
    }
    
    /* ============================================
       BODY - iOS List Style
       ============================================ */
    
    .clawfi-body {
      max-height: 380px;
      overflow-y: auto;
    }
    
    .clawfi-body::-webkit-scrollbar {
      width: 6px;
    }
    
    .clawfi-body::-webkit-scrollbar-track {
      background: transparent;
    }
    
    .clawfi-body::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.15);
      border-radius: 3px;
    }
    
    /* ============================================
       SECTIONS - iOS Grouped Table Style
       ============================================ */
    
    .clawfi-section {
      padding: 18px 20px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.06);
    }
    
    .clawfi-section:last-child {
      border-bottom: none;
    }
    
    .clawfi-section-title {
      font-size: 11px;
      color: var(--text-tertiary);
      text-transform: uppercase;
      letter-spacing: 0.06em;
      margin-bottom: 14px;
      font-weight: 600;
    }
    
    .clawfi-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 12px;
    }
    
    .clawfi-row:last-child {
      margin-bottom: 0;
    }
    
    .clawfi-row-label {
      color: var(--text-secondary);
      font-size: 14px;
    }
    
    .clawfi-row-value {
      color: var(--text-primary);
      font-size: 14px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    
    /* ============================================
       ADDRESS CHIP - iOS Style
       ============================================ */
    
    .clawfi-address {
      font-family: 'SF Mono', 'Menlo', Monaco, monospace;
      background: rgba(255, 255, 255, 0.08);
      backdrop-filter: blur(10px);
      padding: 6px 12px;
      border-radius: 10px;
      font-size: 12px;
      border: 1px solid rgba(255, 255, 255, 0.1);
      letter-spacing: 0.02em;
    }
    
    .clawfi-copy-btn {
      background: rgba(255, 255, 255, 0.08);
      border: 1px solid rgba(255, 255, 255, 0.1);
      color: var(--text-secondary);
      cursor: pointer;
      padding: 6px 8px;
      border-radius: 8px;
      font-size: 12px;
      transition: all 0.2s ease;
    }
    
    .clawfi-copy-btn:hover {
      color: var(--blue);
      background: rgba(10, 132, 255, 0.15);
      border-color: rgba(10, 132, 255, 0.3);
    }
    
    /* ============================================
       MARKET DATA GRID - Dexscreener
       ============================================ */
    
    .clawfi-market-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 10px;
      margin-top: 14px;
    }
    
    .clawfi-market-card {
      background: rgba(255, 255, 255, 0.05);
      border-radius: 14px;
      padding: 12px 14px;
      border: 1px solid rgba(255, 255, 255, 0.08);
      transition: all 0.2s ease;
    }
    
    .clawfi-market-card:hover {
      background: rgba(255, 255, 255, 0.08);
      border-color: rgba(255, 255, 255, 0.12);
    }
    
    .clawfi-market-label {
      font-size: 10px;
      color: var(--text-tertiary);
      text-transform: uppercase;
      letter-spacing: 0.04em;
      margin-bottom: 4px;
    }
    
    .clawfi-market-value {
      font-size: 18px;
      font-weight: 600;
      color: var(--text-primary);
    }
    
    .clawfi-market-sub {
      font-size: 11px;
      color: var(--text-secondary);
      margin-top: 2px;
    }
    
    .clawfi-market-change {
      font-size: 12px;
      font-weight: 500;
      margin-top: 2px;
    }
    
    .clawfi-market-change.positive {
      color: var(--green);
    }
    
    .clawfi-market-change.negative {
      color: var(--red);
    }
    
    .clawfi-dexscreener-link {
      color: var(--blue);
      text-decoration: none;
      font-size: 11px;
      display: inline-block;
      margin-top: 4px;
    }
    
    .clawfi-dexscreener-link:hover {
      text-decoration: underline;
    }
    
    /* ============================================
       BADGES - iOS Pill Style
       ============================================ */
    
    .clawfi-badge {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      padding: 5px 12px;
      border-radius: 100px;
      font-size: 12px;
      font-weight: 500;
      backdrop-filter: blur(10px);
    }
    
    .clawfi-badge-base {
      background: rgba(10, 132, 255, 0.2);
      color: var(--teal);
      border: 1px solid rgba(10, 132, 255, 0.35);
    }
    
    .clawfi-badge-version {
      background: rgba(191, 90, 242, 0.2);
      color: #D4A5FF;
      border: 1px solid rgba(191, 90, 242, 0.35);
    }
    
    .clawfi-badge-verified {
      background: rgba(48, 209, 88, 0.2);
      color: var(--green);
      border: 1px solid rgba(48, 209, 88, 0.35);
    }
    
    .clawfi-badges-container {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
    }
    
    /* Alert badges */
    .clawfi-alert-badge {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      padding: 5px 12px;
      border-radius: 100px;
      font-size: 11px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s ease;
      backdrop-filter: blur(10px);
    }
    
    .clawfi-alert-badge:hover {
      transform: scale(1.05);
    }
    
    .clawfi-alert-launch {
      background: rgba(48, 209, 88, 0.2);
      color: var(--green);
      border: 1px solid rgba(48, 209, 88, 0.35);
    }
    
    .clawfi-alert-concentration {
      background: rgba(255, 159, 10, 0.2);
      color: var(--orange);
      border: 1px solid rgba(255, 159, 10, 0.35);
    }
    
    .clawfi-alert-liquidity {
      background: rgba(255, 69, 58, 0.2);
      color: var(--red);
      border: 1px solid rgba(255, 69, 58, 0.35);
    }
    
    /* ============================================
       LINKS - iOS Style
       ============================================ */
    
    .clawfi-link {
      color: var(--blue);
      text-decoration: none;
      transition: opacity 0.2s;
    }
    
    .clawfi-link:hover {
      opacity: 0.7;
    }
    
    /* ============================================
       SIGNALS LIST - iOS Cell Style
       ============================================ */
    
    .clawfi-signals-empty {
      padding: 32px;
      text-align: center;
      color: var(--text-tertiary);
      font-size: 14px;
    }
    
    .clawfi-signal {
      padding: 16px 20px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.05);
      transition: background 0.2s ease;
    }
    
    .clawfi-signal:last-child {
      border-bottom: none;
    }
    
    .clawfi-signal:hover {
      background: rgba(255, 255, 255, 0.04);
    }
    
    .clawfi-signal-header {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 6px;
    }
    
    .clawfi-signal-dot {
      width: 10px;
      height: 10px;
      border-radius: 50%;
      flex-shrink: 0;
      box-shadow: 0 0 8px currentColor;
    }
    
    .clawfi-signal-title {
      color: var(--text-primary);
      font-weight: 500;
      font-size: 14px;
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    
    .clawfi-signal-summary {
      color: var(--text-secondary);
      font-size: 13px;
      margin-left: 22px;
      margin-bottom: 6px;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
      line-height: 1.5;
    }
    
    .clawfi-signal-meta {
      color: var(--text-tertiary);
      font-size: 12px;
      margin-left: 22px;
    }
    
    /* ============================================
       ASSIST MODE - Action Cards
       ============================================ */
    
    .clawfi-assist-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 10px;
      padding: 16px 20px;
    }
    
    .clawfi-assist-action {
      background: rgba(255, 255, 255, 0.06);
      backdrop-filter: blur(20px);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 14px;
      padding: 14px;
      cursor: pointer;
      transition: all 0.2s ease;
      text-decoration: none;
      display: block;
    }
    
    .clawfi-assist-action:hover {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(10, 132, 255, 0.4);
      transform: translateY(-2px);
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);
    }
    
    .clawfi-assist-action-icon {
      font-size: 24px;
      margin-bottom: 8px;
    }
    
    .clawfi-assist-action-label {
      color: var(--text-primary);
      font-size: 13px;
      font-weight: 500;
      margin-bottom: 2px;
    }
    
    .clawfi-assist-action-desc {
      color: var(--text-tertiary);
      font-size: 11px;
    }
    
    .clawfi-assist-warning {
      margin: 0 20px 16px;
      padding: 14px 16px;
      background: rgba(255, 159, 10, 0.15);
      border: 1px solid rgba(255, 159, 10, 0.3);
      border-radius: 12px;
      display: flex;
      align-items: flex-start;
      gap: 12px;
    }
    
    .clawfi-assist-warning-icon {
      font-size: 18px;
      flex-shrink: 0;
    }
    
    .clawfi-assist-warning-text {
      color: var(--text-secondary);
      font-size: 12px;
      line-height: 1.5;
    }
    
    .clawfi-assist-warning strong {
      color: var(--orange);
    }
    
    /* ============================================
       LOADING STATE - iOS Activity Indicator
       ============================================ */
    
    .clawfi-loading {
      padding: 32px;
      text-align: center;
      color: var(--text-tertiary);
    }
    
    .clawfi-loading-spinner {
      width: 30px;
      height: 30px;
      border: 2.5px solid rgba(255, 255, 255, 0.1);
      border-top-color: var(--blue);
      border-radius: 50%;
      animation: clawfi-spin 0.8s linear infinite;
      margin: 0 auto 12px;
    }
    
    @keyframes clawfi-spin {
      to { transform: rotate(360deg); }
    }
    
    /* ============================================
       ERROR STATE - iOS Alert Style
       ============================================ */
    
    .clawfi-error {
      padding: 18px;
      background: rgba(255, 69, 58, 0.15);
      border: 1px solid rgba(255, 69, 58, 0.3);
      border-radius: 16px;
      margin: 16px 20px;
      backdrop-filter: blur(10px);
    }
    
    .clawfi-error-text {
      color: #FF8A80;
      font-size: 13px;
      margin-bottom: 14px;
    }
    
    .clawfi-retry-btn {
      background: rgba(255, 69, 58, 0.3);
      color: white;
      border: 1px solid rgba(255, 69, 58, 0.5);
      padding: 10px 18px;
      border-radius: 100px;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s ease;
    }
    
    .clawfi-retry-btn:hover {
      background: rgba(255, 69, 58, 0.4);
      transform: scale(1.02);
    }
    
    /* ============================================
       FOOTER - iOS Toolbar Style
       ============================================ */
    
    .clawfi-footer {
      padding: 14px 20px;
      background: rgba(255, 255, 255, 0.03);
      border-top: 1px solid rgba(255, 255, 255, 0.06);
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    
    .clawfi-footer-text {
      color: var(--text-tertiary);
      font-size: 11px;
    }
    
    /* ============================================
       BUTTONS - iOS Liquid Glass Style
       ============================================ */
    
    .clawfi-dashboard-btn {
      background: rgba(10, 132, 255, 0.5);
      color: white;
      border: 1px solid rgba(10, 132, 255, 0.6);
      padding: 10px 18px;
      border-radius: 100px;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      text-decoration: none;
      transition: all 0.2s ease;
      backdrop-filter: blur(10px);
      position: relative;
      overflow: hidden;
    }
    
    .clawfi-dashboard-btn::before {
      content: '';
      position: absolute;
      inset: 0;
      background: linear-gradient(180deg, rgba(255,255,255,0.25) 0%, transparent 50%);
      pointer-events: none;
    }
    
    .clawfi-dashboard-btn:hover {
      background: rgba(10, 132, 255, 0.65);
      transform: scale(1.03);
      box-shadow: 0 4px 16px rgba(10, 132, 255, 0.4);
    }
    
    /* ============================================
       SUCCESS TOAST
       ============================================ */
    
    .clawfi-toast {
      position: fixed;
      bottom: 100px;
      left: 50%;
      transform: translateX(-50%);
      background: rgba(48, 209, 88, 0.9);
      backdrop-filter: blur(20px);
      color: white;
      padding: 12px 24px;
      border-radius: 100px;
      font-size: 14px;
      font-weight: 500;
      z-index: 2147483648;
      animation: toastIn 0.3s ease, toastOut 0.3s ease 1.7s forwards;
      box-shadow: 0 8px 32px rgba(48, 209, 88, 0.4);
    }
    
    @keyframes toastIn {
      from {
        opacity: 0;
        transform: translateX(-50%) translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateX(-50%) translateY(0);
      }
    }
    
    @keyframes toastOut {
      from {
        opacity: 1;
        transform: translateX(-50%) translateY(0);
      }
      to {
        opacity: 0;
        transform: translateX(-50%) translateY(-20px);
      }
    }
  `}function N(a){const{metadata:e,signals:t,badges:r,loading:n,error:o,expanded:p,closed:s,activeTab:l}=a,x=z(48);if(s)return"";const k=[r.hasConcentration,r.hasLiquidityRisk].filter(Boolean).length;if(!p)return`
      <div class="clawfi-overlay">
        <button class="clawfi-fab ${k>0?"clawfi-fab-risk":""}" data-action="expand">
          ${x?`<img class="clawfi-fab-icon" src="${x}" alt="ClawFi">`:'<span class="clawfi-fab-icon-emoji">🦀</span>'}
          ${t.length>0?`<span class="clawfi-fab-badge">${t.length}</span>`:""}
          ${k>0?'<span class="clawfi-fab-risk-dot"></span>':""}
        </button>
      </div>
    `;let b="";return l==="signals"?n?b=`
        <div class="clawfi-loading">
          <div class="clawfi-loading-spinner"></div>
          <div>Loading signals...</div>
        </div>
      `:o?b=`
        <div class="clawfi-error">
          <div class="clawfi-error-text">${o}</div>
          <button class="clawfi-retry-btn" data-action="retry">Retry</button>
        </div>
      `:t.length===0?b=`
        <div class="clawfi-signals-empty">
          <div style="font-size: 32px; margin-bottom: 12px;">✨</div>
          <div>No signals detected</div>
          <div style="font-size: 12px; margin-top: 4px; color: var(--text-tertiary);">This token appears clean</div>
        </div>
      `:b=t.map(g=>`
        <div class="clawfi-signal">
          <div class="clawfi-signal-header">
            <span class="clawfi-signal-dot" style="background: ${S(g.severity)}; color: ${S(g.severity)}"></span>
            <span class="clawfi-signal-title">${C(g.title)}</span>
          </div>
          <div class="clawfi-signal-summary">${C(g.summary.slice(0,120))}${g.summary.length>120?"...":""}</div>
          <div class="clawfi-signal-meta">${L(g.ts)} • ${g.recommendedAction.replace(/_/g," ")}</div>
        </div>
      `).join(""):l==="market"?a.marketData?b=`
        <div class="clawfi-section">
          <div class="clawfi-section-title">Live Market Data</div>
          <div class="clawfi-market-grid">
            <div class="clawfi-market-card">
              <div class="clawfi-market-label">Price</div>
              <div class="clawfi-market-value">$${a.marketData.priceUsd<.01?a.marketData.priceUsd.toExponential(2):a.marketData.priceUsd.toFixed(4)}</div>
              <div class="clawfi-market-change ${a.marketData.priceChange24h>=0?"positive":"negative"}">
                ${a.marketData.priceChange24h>=0?"+":""}${a.marketData.priceChange24h.toFixed(2)}% (24h)
              </div>
            </div>
            <div class="clawfi-market-card">
              <div class="clawfi-market-label">Volume 24h</div>
              <div class="clawfi-market-value">$${y(a.marketData.volume24h)}</div>
              <div class="clawfi-market-sub">${a.marketData.txns24h.buys}↑ ${a.marketData.txns24h.sells}↓</div>
            </div>
            <div class="clawfi-market-card">
              <div class="clawfi-market-label">Liquidity</div>
              <div class="clawfi-market-value">$${y(a.marketData.liquidity)}</div>
              <div class="clawfi-market-sub">${a.marketData.dex}</div>
            </div>
            <div class="clawfi-market-card">
              <div class="clawfi-market-label">Market Cap</div>
              <div class="clawfi-market-value">${a.marketData.marketCap?"$"+y(a.marketData.marketCap):"N/A"}</div>
              <a class="clawfi-dexscreener-link" href="${a.marketData.dexscreenerUrl}" target="_blank">View on DEXScreener ↗</a>
            </div>
          </div>
        </div>
        
        <div class="clawfi-section">
          <div class="clawfi-section-title">Token Info</div>
          <div class="clawfi-row">
            <span class="clawfi-row-label">Address</span>
            <span class="clawfi-row-value">
              <code class="clawfi-address">${O(e.address)}</code>
              <button class="clawfi-copy-btn" data-action="copy" data-value="${e.address}">📋</button>
            </span>
          </div>
          <div class="clawfi-row">
            <span class="clawfi-row-label">Chain</span>
            <span class="clawfi-row-value">
              <span class="clawfi-badge clawfi-badge-base">⬡ Base</span>
            </span>
          </div>
          ${e.version?`
          <div class="clawfi-row">
            <span class="clawfi-row-label">Version</span>
            <span class="clawfi-row-value">
              <span class="clawfi-badge clawfi-badge-version">${e.version}</span>
            </span>
          </div>
          `:""}
        </div>
      `:b=`
        <div class="clawfi-signals-empty">
          <div style="font-size: 32px; margin-bottom: 12px;">📊</div>
          <div>Loading market data...</div>
          <div style="font-size: 12px; margin-top: 4px; color: var(--text-tertiary);">Fetching from DEXScreener</div>
        </div>
      `:l==="assist"&&(b=`
      <div class="clawfi-assist-warning">
        <span class="clawfi-assist-warning-icon">⚡</span>
        <div class="clawfi-assist-warning-text">
          <strong>Assist Mode</strong> provides quick actions for this token. 
          ClawFi never signs transactions automatically — you always review first.
        </div>
      </div>
      
      <div class="clawfi-assist-grid">
        ${R(e).map(d=>d.type==="link"?`
              <a class="clawfi-assist-action" href="${d.url}" target="_blank" rel="noopener">
                <div class="clawfi-assist-action-icon">${d.icon}</div>
                <div class="clawfi-assist-action-label">${d.label}</div>
                <div class="clawfi-assist-action-desc">${d.description}</div>
              </a>
            `:d.type==="copy"?`
              <button class="clawfi-assist-action" data-action="copy" data-value="${d.value}">
                <div class="clawfi-assist-action-icon">${d.icon}</div>
                <div class="clawfi-assist-action-label">${d.label}</div>
                <div class="clawfi-assist-action-desc">${d.description}</div>
              </button>
            `:"").join("")}
      </div>
    `),`
    <div class="clawfi-overlay">
      <div class="clawfi-panel">
        <div class="clawfi-header">
          <div class="clawfi-header-title">
            ${x?`<img class="clawfi-header-logo" src="${x}" alt="">`:"<span>🦀</span>"}
            <span>${e.symbol||e.name||"ClawFi"}</span>
          </div>
          <div class="clawfi-header-actions">
            <button class="clawfi-header-btn" data-action="collapse" title="Minimize">−</button>
            <button class="clawfi-header-btn" data-action="close" title="Close">×</button>
          </div>
        </div>
        
        <div class="clawfi-tabs">
          <button class="clawfi-tab ${l==="signals"?"active":""}" data-tab="signals">
            <span class="clawfi-tab-icon">🚨</span>
            Signals
            ${t.length>0?`<span class="clawfi-tab-badge">${t.length}</span>`:""}
          </button>
          <button class="clawfi-tab ${l==="market"?"active":""}" data-tab="market">
            <span class="clawfi-tab-icon">📊</span>
            Market
          </button>
          <button class="clawfi-tab ${l==="assist"?"active":""}" data-tab="assist">
            <span class="clawfi-tab-icon">⚡</span>
            Assist
          </button>
        </div>
        
        <div class="clawfi-body">
          ${b}
        </div>
        
        <div class="clawfi-footer">
          <span class="clawfi-footer-text">ClawFi v${D}</span>
          <a class="clawfi-dashboard-btn" data-action="dashboard">Open Dashboard</a>
        </div>
      </div>
    </div>
  `}function C(a){const e=document.createElement("div");return e.textContent=a,e.innerHTML}function U(a){if(!c)return;const e=c.querySelector(".clawfi-toast");e&&e.remove();const t=document.createElement("div");t.className="clawfi-toast",t.textContent=a,c.appendChild(t),setTimeout(()=>t.remove(),2e3)}async function T(a){return new Promise(e=>{try{chrome.runtime.sendMessage({type:"GET_SIGNALS",token:a,chain:"base",limit:5},t=>{if(chrome.runtime.lastError){console.warn("[ClawFi] Signal fetch error:",chrome.runtime.lastError),e([]);return}Array.isArray(t)?e(t):e([])})}catch(t){console.warn("[ClawFi] Signal fetch exception:",t),e([])}})}async function q(a){return new Promise(e=>{try{chrome.runtime.sendMessage({type:"GET_SETTINGS"},async t=>{if(chrome.runtime.lastError||!t){e(null);return}try{const r=t.nodeUrl||"https://api.clawfi.ai",n=await fetch(`${r}/dexscreener/token/${a}?chain=base`,{headers:t.authToken?{Authorization:`Bearer ${t.authToken}`}:{}});if(!n.ok){e(null);return}const o=await n.json();o.success&&o.data?e({priceUsd:o.data.priceUsd||0,priceChange24h:o.data.priceChange24h||0,priceChangeH1:o.data.priceChangeH1||0,volume24h:o.data.volume24h||0,liquidity:o.data.liquidity||0,marketCap:o.data.marketCap,txns24h:o.data.txns24h||{buys:0,sells:0},dex:o.data.dex||"unknown",dexscreenerUrl:o.data.dexscreenerUrl||""}):e(null)}catch(r){console.warn("[ClawFi] Market data fetch error:",r),e(null)}})}catch(t){console.warn("[ClawFi] Market data fetch exception:",t),e(null)}})}async function G(){let a="https://dashboard.clawfi.ai";i!=null&&i.metadata.address&&(a+=`/signals?token=${i.metadata.address}`),window.open(a,"_blank")}function f(){!c||!i||(c.innerHTML=`
    <style>${I()}</style>
    ${N(i)}
  `,P())}function P(){if(!c)return;const a=c.querySelector('[data-action="expand"]');a==null||a.addEventListener("click",()=>{i&&(i.expanded=!0,f())});const e=c.querySelector('[data-action="collapse"]');e==null||e.addEventListener("click",()=>{i&&(i.expanded=!1,f())});const t=c.querySelector('[data-action="close"]');t==null||t.addEventListener("click",()=>{i&&(i.closed=!0,f())}),c.querySelectorAll("[data-tab]").forEach(s=>{s.addEventListener("click",()=>{if(i){const l=s.dataset.tab;i.activeTab=l,f()}})}),c.querySelectorAll('[data-action="copy"]').forEach(s=>{s.addEventListener("click",async l=>{l.preventDefault(),l.stopPropagation();const x=l.currentTarget.dataset.value;x&&(await M(x),U("Copied to clipboard!"))})});const o=c.querySelector('[data-action="retry"]');o==null||o.addEventListener("click",async()=>{if(i){i.loading=!0,i.error=null,f();try{const s=await T(i.metadata.address);i.signals=s,i.loading=!1}catch{i.error="Failed to connect to ClawFi Node",i.loading=!1}f()}});const p=c.querySelector('[data-action="dashboard"]');p==null||p.addEventListener("click",s=>{s.preventDefault(),G()})}function j(a){return{hasLaunch:a.some(e=>e.signalType==="LaunchDetected"),hasConcentration:a.some(e=>e.signalType==="EarlyDistribution"),hasLiquidityRisk:a.some(e=>e.signalType==="LiquidityRisk")}}async function _(a){u||(u=document.createElement("div"),u.id=E,document.body.appendChild(u),c=u.attachShadow({mode:"closed"})),i={metadata:a,signals:[],badges:{hasLaunch:!1,hasConcentration:!1,hasLiquidityRisk:!1},marketData:null,loading:!0,error:null,expanded:!1,closed:!1,assistModeOpen:!1,activeTab:"signals"},f();try{const[e,t]=await Promise.all([T(a.address),q(a.address)]);i&&i.metadata.address===a.address&&(i.signals=e,i.badges=j(e),i.marketData=t,i.loading=!1,f())}catch{i&&i.metadata.address===a.address&&(i.error="Unable to reach ClawFi Node",i.loading=!1,f())}}function B(){u&&(u.remove(),u=null,c=null,i=null)}const H=/^0x[a-fA-F0-9]{40}$/,V=/^\/clanker\/(0x[a-fA-F0-9]{40})/i;function m(){const e=window.location.pathname.match(V);if(e&&e[1]){const t=e[1];if(H.test(t))return t}return null}function X(){const a={};try{const e=document.body.innerText||"",t=e.match(/\bV(3(?:\.1)?|4)\b/i);t&&(a.version=`V${t[1]}`);const r=e.match(/Creator[:\s]+(?:\n|\s)*(0x[a-fA-F0-9]{40})/i);r&&r[1]&&(a.creator=r[1]);const n=e.match(/Admin[:\s]+(?:\n|\s)*(0x[a-fA-F0-9]{40})/i);n&&n[1]&&(a.admin=n[1]),/verified\s*token|✓\s*verified|\bverified\b/i.test(e)&&(a.verified=!0);const p=document.title.match(/^([^|–-]+)/);if(p&&p[1]){const s=p[1].trim().split(/\s+/);if(s.length>=1&&(a.name=s.slice(0,-1).join(" ")||s[0],s.length>1)){const l=s[s.length-1];l&&l.length<=10&&/^[A-Z0-9$]+$/i.test(l)&&(a.symbol=l.toUpperCase())}}}catch(e){console.debug("[ClawFi] Metadata extraction error (non-fatal):",e)}return a}function Y(a){const e=X();return{address:a,chain:"base",...e}}let v=null,h=!1;async function $(a,e=3){for(let t=0;t<e;t++)try{return await new Promise((r,n)=>{chrome.runtime.sendMessage(a,o=>{chrome.runtime.lastError?n(chrome.runtime.lastError):r(o)})})}catch(r){console.warn(`[ClawFi] Message failed (attempt ${t+1}/${e}):`,r),t<e-1&&await new Promise(n=>setTimeout(n,500*(t+1)))}return null}async function w(){const a=m();if(console.log("[ClawFi] Route change detected, token:",a),a===v&&h||(h&&(B(),h=!1),v=a,!a))return;let e=!0;try{const t=await $({type:"GET_SETTINGS"});t&&(t.clankerOverlayEnabled===!1||t.overlayEnabled===!1)&&(e=!1)}catch(t){console.warn("[ClawFi] Error getting settings, defaulting to enabled:",t)}if(!e){console.log("[ClawFi] Overlay disabled in settings");return}setTimeout(()=>{if(v===a){console.log("[ClawFi] Rendering overlay for token:",a);const t=Y(a);_(t),h=!0,$({type:"DETECTED_TOKEN",token:a,chain:"base",source:"clanker"}).catch(()=>{})}},500)}function K(){const a=history.pushState.bind(history),e=history.replaceState.bind(history);history.pushState=function(...r){const n=a(...r);return w(),n},history.replaceState=function(...r){const n=e(...r);return w(),n},window.addEventListener("popstate",()=>{w()}),window.addEventListener("hashchange",()=>{w()}),new MutationObserver(()=>{m()!==v&&w()}).observe(document.body,{childList:!0,subtree:!0})}function F(){console.log("[ClawFi] Clanker content script initialized on:",window.location.href),console.log("[ClawFi] Current pathname:",window.location.pathname);const a=m();console.log("[ClawFi] Token from URL:",a),K(),w()}document.readyState==="loading"?(console.log("[ClawFi] Waiting for DOMContentLoaded..."),document.addEventListener("DOMContentLoaded",F)):(console.log("[ClawFi] DOM already ready, initializing..."),F());setTimeout(()=>{m()&&!h&&(console.log("[ClawFi] Delayed check - token found but overlay not mounted, retrying..."),w())},2e3);
