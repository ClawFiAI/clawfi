import{d as m}from"../chunks/dexscreener.js";const l={WATCHLIST:"clawfi_watchlist",ALERTS:"clawfi_alerts",RECENT_TOKENS:"clawfi_recent",TRACKED_WALLETS:"clawfi_wallets",PREFERENCES:"clawfi_prefs"};async function k(){try{return(await chrome.storage.local.get(l.WATCHLIST))[l.WATCHLIST]||[]}catch{return[]}}async function w(){try{return(await chrome.storage.local.get(l.ALERTS))[l.ALERTS]||[]}catch{return[]}}async function y(){try{return(await chrome.storage.local.get(l.RECENT_TOKENS))[l.RECENT_TOKENS]||[]}catch{return[]}}const i={logo:`<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="50" cy="50" r="45" fill="url(#logoGrad)"/>
    <ellipse cx="35" cy="40" rx="8" ry="10" fill="white"/>
    <ellipse cx="65" cy="40" rx="8" ry="10" fill="white"/>
    <circle cx="35" cy="40" r="4" fill="#0A84FF"/>
    <circle cx="65" cy="40" r="4" fill="#0A84FF"/>
    <path d="M30 65 Q50 80 70 65" stroke="white" stroke-width="4" fill="none" stroke-linecap="round"/>
    <path d="M15 35 L5 25 L15 30" stroke="white" stroke-width="3" fill="none" stroke-linecap="round"/>
    <path d="M85 35 L95 25 L85 30" stroke="white" stroke-width="3" fill="none" stroke-linecap="round"/>
    <defs>
      <linearGradient id="logoGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#0A84FF"/>
        <stop offset="100%" stop-color="#5856D6"/>
      </linearGradient>
    </defs>
  </svg>`,home:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>',star:'<svg viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',fire:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 23c-3.65 0-6.5-2.85-6.5-6.5 0-2.68 2.08-5.35 4.5-7.5 2.42 2.15 4.5 4.82 4.5 7.5 0 3.65-2.85 6.5-6.5 6.5zM12 1c0 4-3 7-3 11 0 3.31 2.69 6 6 6s6-2.69 6-6c0-6-6-11-9-11z"/></svg>',bell:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"/></svg>',refresh:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>',settings:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',chart:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="20" x2="12" y2="10"/><line x1="18" y1="20" x2="18" y2="4"/><line x1="6" y1="20" x2="6" y2="16"/></svg>',rocket:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="M12 15l-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/></svg>',globe:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>',gem:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>',search:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',clock:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',coin:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v2m0 8v2m-4-6h2m6 0h2"/></svg>',externalLink:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>',trophy:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"/></svg>',sparkle:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 0L14.59 8.41L23 11L14.59 13.59L12 22L9.41 13.59L1 11L9.41 8.41L12 0Z"/></svg>',trendUp:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>'};let t={activeTab:"home",loading:!0,connected:!0,error:null,watchlist:[],alerts:[],recent:[],trending:[],trendingLoading:!1,gems:[],gemsLoading:!1};const $=`
  * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
  }
  
  @import url('https://fonts.googleapis.com/css2?family=Doto:wght@100;200;300;400;500;600;700;800;900&display=swap');
  
  html, body {
    width: 400px;
    height: 580px;
    max-width: 400px;
    max-height: 580px;
    overflow: hidden;
    font-family: 'Doto', monospace;
    background: linear-gradient(145deg, #0a0a12 0%, #12121a 50%, #0d0d15 100%);
    color: rgba(255, 255, 255, 0.95);
    -webkit-font-smoothing: antialiased;
  }
  
  body::before {
    content: '';
    position: fixed;
    inset: 0;
    background: 
      radial-gradient(ellipse at 20% 0%, rgba(10, 132, 255, 0.15) 0%, transparent 50%),
      radial-gradient(ellipse at 80% 100%, rgba(88, 86, 214, 0.12) 0%, transparent 50%);
    pointer-events: none;
  }
  
  .popup {
    display: flex;
    flex-direction: column;
    height: 580px;
    max-height: 580px;
    width: 400px;
    position: relative;
    z-index: 1;
    overflow: hidden;
  }
  
  .header {
    flex-shrink: 0;
    padding: 20px;
    background: linear-gradient(180deg, rgba(10, 132, 255, 0.2) 0%, transparent 100%);
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  }
  
  .header-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 16px;
  }
  
  .brand {
    display: flex;
    align-items: center;
    gap: 12px;
  }
  
  .logo {
    width: 44px;
    height: 44px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 4px 16px rgba(10, 132, 255, 0.3);
  }
  
  .logo svg {
    width: 44px;
    height: 44px;
  }
  
  .brand-text h1 {
    font-size: 20px;
    font-weight: 700;
    letter-spacing: -0.5px;
  }
  
  .brand-text span {
    font-size: 12px;
    color: rgba(255, 255, 255, 0.5);
  }
  
  .header-actions {
    display: flex;
    gap: 8px;
  }
  
  .icon-btn {
    width: 38px;
    height: 38px;
    border: 1px solid rgba(255, 255, 255, 0.15);
    border-radius: 10px;
    background: rgba(255, 255, 255, 0.05);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s;
    color: rgba(255, 255, 255, 0.7);
  }
  
  .icon-btn svg {
    width: 18px;
    height: 18px;
  }
  
  .icon-btn:hover {
    background: rgba(255, 255, 255, 0.1);
    color: white;
  }
  
  .status-bar {
    display: flex;
    gap: 12px;
  }
  
  .status-item {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 6px 12px;
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 100px;
    font-size: 12px;
  }
  
  .status-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #30D158;
    box-shadow: 0 0 8px #30D158;
  }
  
  .status-dot.offline {
    background: #FF453A;
    box-shadow: 0 0 8px #FF453A;
  }
  
  .tabs {
    flex-shrink: 0;
    display: flex;
    padding: 10px 12px;
    gap: 4px;
    background: rgba(0, 0, 0, 0.2);
    border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    overflow-x: auto;
  }
  
  .tab {
    flex: 1;
    min-width: 60px;
    padding: 10px 6px;
    border: none;
    border-radius: 10px;
    background: transparent;
    color: rgba(255, 255, 255, 0.6);
    font-size: 11px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 4px;
  }
  
  .tab:hover {
    background: rgba(255, 255, 255, 0.05);
    color: rgba(255, 255, 255, 0.9);
  }
  
  .tab.active {
    background: rgba(10, 132, 255, 0.2);
    color: #0A84FF;
    border: 1px solid rgba(10, 132, 255, 0.3);
  }
  
  .tab-icon {
    width: 20px;
    height: 20px;
  }
  
  .tab-icon svg {
    width: 100%;
    height: 100%;
  }
  
  .tab-badge {
    background: #FF453A;
    color: white;
    font-size: 9px;
    padding: 1px 5px;
    border-radius: 10px;
    margin-left: 2px;
  }
  
  .content {
    flex: 1 1 auto;
    min-height: 0;
    overflow-y: auto;
    overflow-x: hidden;
    padding: 16px;
  }
  
  .content::-webkit-scrollbar {
    width: 4px;
  }
  
  .content::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.15);
    border-radius: 2px;
  }
  
  .stats-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 10px;
    margin-bottom: 16px;
  }
  
  .stat-card {
    padding: 14px;
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 14px;
  }
  
  .stat-label {
    font-size: 10px;
    color: rgba(255, 255, 255, 0.4);
    text-transform: uppercase;
    letter-spacing: 0.05em;
    margin-bottom: 4px;
  }
  
  .stat-value {
    font-size: 24px;
    font-weight: 700;
    color: #0A84FF;
  }
  
  .quick-actions {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 8px;
    margin-bottom: 16px;
  }
  
  .quick-action {
    padding: 12px 6px;
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 12px;
    background: rgba(255, 255, 255, 0.03);
    text-decoration: none;
    text-align: center;
    cursor: pointer;
    transition: all 0.2s;
    color: inherit;
  }
  
  .quick-action:hover {
    background: rgba(255, 255, 255, 0.08);
    transform: translateY(-2px);
  }
  
  .quick-action-icon {
    width: 24px;
    height: 24px;
    margin: 0 auto 4px;
    color: #0A84FF;
  }
  
  .quick-action-icon svg {
    width: 100%;
    height: 100%;
  }
  
  .quick-action-label {
    font-size: 10px;
    color: rgba(255, 255, 255, 0.6);
  }
  
  .card {
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 16px;
    overflow: hidden;
    margin-bottom: 14px;
  }
  
  .card-header {
    padding: 12px 14px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid rgba(255, 255, 255, 0.08);
  }
  
  .card-title {
    font-size: 13px;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 8px;
  }
  
  .card-title svg {
    width: 16px;
    height: 16px;
    color: #0A84FF;
  }
  
  .card-body {
    padding: 0;
  }
  
  .empty-state {
    text-align: center;
    padding: 24px;
    color: rgba(255, 255, 255, 0.4);
  }
  
  .empty-icon {
    width: 40px;
    height: 40px;
    margin: 0 auto 10px;
    opacity: 0.5;
    color: rgba(255, 255, 255, 0.3);
  }
  
  .empty-icon svg {
    width: 100%;
    height: 100%;
  }
  
  .token-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 14px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.06);
    cursor: pointer;
    transition: background 0.2s;
  }
  
  .token-item:hover {
    background: rgba(255, 255, 255, 0.05);
  }
  
  .token-item:last-child {
    border-bottom: none;
  }
  
  .token-info {
    display: flex;
    align-items: center;
    gap: 10px;
    flex: 1;
    min-width: 0;
  }
  
  .token-icon {
    width: 32px;
    height: 32px;
    border-radius: 10px;
    background: linear-gradient(135deg, rgba(10, 132, 255, 0.3), rgba(88, 86, 214, 0.3));
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    color: #0A84FF;
  }
  
  .token-icon svg {
    width: 16px;
    height: 16px;
  }
  
  .token-icon img {
    width: 100%;
    height: 100%;
    border-radius: 10px;
    object-fit: cover;
  }
  
  .token-details {
    min-width: 0;
    flex: 1;
  }
  
  .token-symbol {
    font-weight: 600;
    font-size: 13px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  
  .token-name {
    font-size: 11px;
    color: rgba(255, 255, 255, 0.5);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  
  .token-chain {
    font-size: 9px;
    color: rgba(255, 255, 255, 0.4);
    background: rgba(255, 255, 255, 0.08);
    padding: 2px 6px;
    border-radius: 4px;
    text-transform: uppercase;
  }
  
  .token-price {
    text-align: right;
    flex-shrink: 0;
  }
  
  .token-price-value {
    font-weight: 600;
    font-size: 13px;
  }
  
  .token-change {
    font-size: 11px;
  }
  
  .token-change.positive {
    color: #30D158;
  }
  
  .token-change.negative {
    color: #FF453A;
  }
  
  .gem-item {
    display: flex;
    align-items: center;
    padding: 12px 14px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.06);
    cursor: pointer;
    transition: all 0.2s;
  }
  
  .gem-item:hover {
    background: rgba(255, 255, 255, 0.05);
  }
  
  .gem-item.mooning {
    background: linear-gradient(90deg, rgba(255, 215, 0, 0.1), transparent);
    border-left: 3px solid #FFD700;
  }
  
  .gem-score {
    width: 36px;
    height: 36px;
    border-radius: 10px;
    background: linear-gradient(135deg, #0A84FF, #5856D6);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 12px;
    font-weight: 700;
    margin-right: 12px;
  }
  
  .gem-signal {
    font-size: 10px;
    padding: 3px 8px;
    border-radius: 6px;
    background: rgba(10, 132, 255, 0.2);
    color: #0A84FF;
    margin-top: 4px;
    display: inline-block;
  }
  
  .gem-change {
    margin-left: auto;
    font-size: 14px;
    font-weight: 700;
  }
  
  .gem-change.positive {
    color: #30D158;
  }
  
  .gem-change.huge {
    color: #FFD700;
    text-shadow: 0 0 10px rgba(255, 215, 0, 0.5);
  }
  
  .alert-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 14px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.06);
  }
  
  .alert-item:last-child {
    border-bottom: none;
  }
  
  .alert-info {
    flex: 1;
  }
  
  .alert-symbol {
    font-weight: 600;
    font-size: 13px;
  }
  
  .alert-condition {
    font-size: 11px;
    color: rgba(255, 255, 255, 0.5);
  }
  
  .alert-status {
    font-size: 9px;
    padding: 3px 8px;
    border-radius: 6px;
  }
  
  .alert-status.active {
    background: rgba(48, 209, 88, 0.2);
    color: #30D158;
  }
  
  .alert-status.triggered {
    background: rgba(255, 149, 0, 0.2);
    color: #FF9500;
  }
  
  .loading-spinner {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 30px;
  }
  
  .spinner {
    width: 24px;
    height: 24px;
    border: 2px solid rgba(255, 255, 255, 0.1);
    border-top-color: #0A84FF;
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
  }
  
  @keyframes spin {
    to { transform: rotate(360deg); }
  }
  
  .footer {
    flex-shrink: 0;
    padding: 12px 16px;
    background: rgba(0, 0, 0, 0.3);
    border-top: 1px solid rgba(255, 255, 255, 0.08);
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  
  .footer-version {
    font-size: 11px;
    color: rgba(255, 255, 255, 0.4);
  }
  
  .btn-dashboard {
    padding: 8px 16px;
    border: none;
    border-radius: 100px;
    background: linear-gradient(135deg, #0A84FF 0%, #5856D6 100%);
    color: white;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 6px;
    transition: all 0.2s;
  }
  
  .btn-dashboard svg {
    width: 14px;
    height: 14px;
  }
  
  .btn-dashboard:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 20px rgba(10, 132, 255, 0.4);
  }
  
  .error-banner {
    background: rgba(255, 69, 58, 0.15);
    border: 1px solid rgba(255, 69, 58, 0.3);
    color: #FF453A;
    padding: 10px 14px;
    border-radius: 10px;
    margin-bottom: 14px;
    font-size: 12px;
  }
  
  .rank-badge {
    width: 22px;
    height: 22px;
    border-radius: 6px;
    background: rgba(255, 255, 255, 0.1);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 10px;
    font-weight: 600;
    color: rgba(255, 255, 255, 0.6);
    margin-right: 8px;
  }
  
  .rank-badge.top3 {
    background: linear-gradient(135deg, #FFD700 0%, #FF9500 100%);
    color: #000;
  }
`;function F(){try{return chrome.runtime.getURL("icons/icon48.png")}catch{return""}}function C(e){return e===0?"$0.00":e<1e-4?`$${e.toExponential(2)}`:e<1?`$${e.toFixed(6)}`:e<1e3?`$${e.toFixed(2)}`:`$${(e/1e3).toFixed(1)}K`}function A(e){const a=e>=0?"+":"";return Math.abs(e)>=1e3?`${a}${(e/1e3).toFixed(1)}K%`:`${a}${e.toFixed(1)}%`}function c(e){return e?`${e.slice(0,6)}...${e.slice(-4)}`:""}function x(e){const a=Math.floor((Date.now()-e)/1e3);return a<60?"Just now":a<3600?`${Math.floor(a/60)}m ago`:a<86400?`${Math.floor(a/3600)}h ago`:`${Math.floor(a/86400)}d ago`}async function f(){try{const[e,a,n]=await Promise.all([k(),w(),y()]);t.watchlist=e,t.alerts=a,t.recent=n,t.loading=!1,s()}catch(e){console.error("[ClawFi] Error loading local data:",e),t.loading=!1,s()}}async function v(){if(!t.trendingLoading){t.trendingLoading=!0,s();try{const e=await m.getBoostedTokens();t.trending=e.slice(0,10)}catch(e){console.error("[ClawFi] Error loading trending:",e),t.trending=[]}t.trendingLoading=!1,s()}}async function g(){if(!t.gemsLoading){t.gemsLoading=!0,s();try{const e=await fetch("https://api.clawfi.ai/clawf/gems");if(e.ok){const a=await e.json();a.success&&a.data&&(t.gems=a.data.slice(0,10).map(n=>{var r,o;return{address:n.address,chain:n.chain||"solana",symbol:n.symbol,name:n.name,score:((r=n.scores)==null?void 0:r.composite)||0,signal:n.bestSignal||((o=n.signals)==null?void 0:o[0])||"New Detection",priceChange1h:n.priceChange1h||0,detectedAt:n.detectedAt||Date.now()}}))}}catch(e){console.error("[ClawFi] Error loading gems:",e),t.gems=[]}t.gemsLoading=!1,s()}}function s(){const e=document.getElementById("app");if(!e)return;const a=F(),n=t.alerts.filter(r=>r.enabled&&!r.triggered).length;e.innerHTML=`
    <div class="popup">
      <div class="header">
        <div class="header-top">
          <div class="brand">
            <div class="logo">
              ${a?`<img src="${a}" alt="ClawFi" style="width:44px;height:44px;border-radius:12px;" onerror="this.style.display='none';this.nextElementSibling.style.display='block';"><div style="display:none;">${i.logo}</div>`:i.logo}
            </div>
            <div class="brand-text">
              <h1>ClawFi</h1>
              <span>Degen Trading Assistant</span>
            </div>
          </div>
          <div class="header-actions">
            <button class="icon-btn" id="refresh-btn" title="Refresh">${i.refresh}</button>
            <button class="icon-btn" id="settings-btn" title="Settings">${i.settings}</button>
          </div>
        </div>
        <div class="status-bar">
          <div class="status-item">
            <span class="status-dot "></span>
            <span>Active</span>
          </div>
          <div class="status-item">
            <span style="width:14px;height:14px;display:inline-flex;">${i.logo}</span>
            <span>v0.5.0</span>
          </div>
        </div>
      </div>
      
      <div class="tabs">
        <button class="tab ${t.activeTab==="home"?"active":""}" data-tab="home">
          <span class="tab-icon">${i.home}</span>
          <span>Home</span>
        </button>
        <button class="tab ${t.activeTab==="gems"?"active":""}" data-tab="gems">
          <span class="tab-icon">${i.gem}</span>
          <span>ClawF${t.gems.length>0?` (${t.gems.length})`:""}</span>
        </button>
        <button class="tab ${t.activeTab==="watchlist"?"active":""}" data-tab="watchlist">
          <span class="tab-icon">${i.star}</span>
          <span>Watch</span>
        </button>
        <button class="tab ${t.activeTab==="trending"?"active":""}" data-tab="trending">
          <span class="tab-icon">${i.fire}</span>
          <span>Hot</span>
        </button>
        <button class="tab ${t.activeTab==="alerts"?"active":""}" data-tab="alerts">
          <span class="tab-icon">${i.bell}</span>
          <span>Alerts${n>0?`<span class="tab-badge">${n}</span>`:""}</span>
        </button>
      </div>
      
      <div class="content">
        
        ${t.loading?h():L()}
      </div>
      
      <div class="footer">
        <span class="footer-version">ClawFi v0.5.0</span>
        <button class="btn-dashboard" id="dashboard-btn">
          ${i.externalLink}
          Open Dashboard
        </button>
      </div>
    </div>
  `,B()}function h(){return`
    <div class="loading-spinner">
      <div class="spinner"></div>
    </div>
  `}function L(){switch(t.activeTab){case"home":return E();case"gems":return z();case"watchlist":return M();case"trending":return j();case"alerts":return D();default:return""}}function E(){const e=t.alerts.filter(a=>a.enabled&&!a.triggered).length;return`
    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-label">Watchlist</div>
        <div class="stat-value">${t.watchlist.length}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Active Alerts</div>
        <div class="stat-value">${e}</div>
      </div>
    </div>
    
    <div class="quick-actions">
      <a class="quick-action" href="https://dexscreener.com" target="_blank">
        <div class="quick-action-icon">${i.chart}</div>
        <span class="quick-action-label">DEXScreener</span>
      </a>
      <a class="quick-action" href="https://jup.ag" target="_blank">
        <div class="quick-action-icon">${i.globe}</div>
        <span class="quick-action-label">Jupiter</span>
      </a>
      <a class="quick-action" href="https://pump.fun" target="_blank">
        <div class="quick-action-icon">${i.rocket}</div>
        <span class="quick-action-label">Pump.fun</span>
      </a>
      <a class="quick-action" href="https://clanker.world" target="_blank">
        <div class="quick-action-icon">${i.sparkle}</div>
        <span class="quick-action-label">Clanker</span>
      </a>
    </div>
    
    <div class="card">
      <div class="card-header">
        <span class="card-title">${i.clock} Recent Activity</span>
      </div>
      <div class="card-body">
        ${t.recent.length>0?T():`
          <div class="empty-state">
            <div class="empty-icon">${i.search}</div>
            <p>Browse DEX sites to see history</p>
          </div>
        `}
      </div>
    </div>
  `}function T(){return t.recent.slice(0,5).map(e=>`
    <div class="token-item" data-address="${e.address}" data-chain="${e.chain}">
      <div class="token-info">
        <div class="token-icon">${i.coin}</div>
        <div class="token-details">
          <div class="token-symbol">${e.symbol||c(e.address)}</div>
          <div class="token-name">${e.name||e.source||"Token"}</div>
        </div>
      </div>
      <div class="token-price">
        <span class="token-chain">${e.chain}</span>
        <div class="token-name">${x(e.lastViewed)}</div>
      </div>
    </div>
  `).join("")}function z(){if(t.gemsLoading)return h();if(t.gems.length===0)return`
      <div class="empty-state">
        <div class="empty-icon">${i.gem}</div>
        <p>No gems detected yet</p>
        <p style="font-size: 11px; margin-top: 6px; color: rgba(255,255,255,0.4)">ClawF is scanning for opportunities</p>
      </div>
    `;const e=[...t.gems].sort((a,n)=>(n.priceChange1h||0)-(a.priceChange1h||0));return`
    <div class="card">
      <div class="card-header">
        <span class="card-title">${i.trophy} ClawF Detections</span>
      </div>
      <div class="card-body">
        ${e.map((a,n)=>{const r=(a.priceChange1h||0)>=100,o=r?"huge":(a.priceChange1h||0)>=0?"positive":"";return`
            <div class="gem-item ${r?"mooning":""}" data-address="${a.address}" data-chain="${a.chain}">
              <div class="gem-score">${Math.round(a.score)}</div>
              <div class="token-details">
                <div class="token-symbol">${a.symbol||c(a.address)}</div>
                <div class="gem-signal">${a.signal}</div>
              </div>
              <div class="gem-change ${o}">
                ${a.priceChange1h?A(a.priceChange1h):"-"}
              </div>
            </div>
          `}).join("")}
      </div>
    </div>
  `}function M(){return t.watchlist.length===0?`
      <div class="empty-state">
        <div class="empty-icon">${i.star}</div>
        <p>No tokens in watchlist</p>
        <p style="font-size: 11px; margin-top: 6px; color: rgba(255,255,255,0.4)">Add tokens while browsing DEX sites</p>
      </div>
    `:`
    <div class="card">
      <div class="card-body">
        ${t.watchlist.map(e=>`
          <div class="token-item" data-address="${e.address}" data-chain="${e.chain}">
            <div class="token-info">
              <div class="token-icon">${i.star}</div>
              <div class="token-details">
                <div class="token-symbol">${e.symbol||c(e.address)}</div>
                <div class="token-name">${e.name||e.chain}</div>
              </div>
            </div>
            <div class="token-price">
              <span class="token-chain">${e.chain}</span>
              <div class="token-name">Added ${x(e.addedAt)}</div>
            </div>
          </div>
        `).join("")}
      </div>
    </div>
  `}function j(){return t.trendingLoading?h():t.trending.length===0?`
      <div class="empty-state">
        <div class="empty-icon">${i.fire}</div>
        <p>No trending tokens found</p>
        <p style="font-size: 11px; margin-top: 6px; color: rgba(255,255,255,0.4)">Pull to refresh</p>
      </div>
    `:`
    <div class="card">
      <div class="card-header">
        <span class="card-title">${i.trendUp} Trending on Dexscreener</span>
      </div>
      <div class="card-body">
        ${t.trending.map((e,a)=>`
          <div class="token-item" data-address="${e.token.address}" data-chain="${e.pair.chain}" data-url="${e.pair.url||""}">
            <div class="token-info">
              <span class="rank-badge ${a<3?"top3":""}">${a+1}</span>
              <div class="token-icon">
                ${e.token.logoUrl?`<img src="${e.token.logoUrl}" onerror="this.parentElement.innerHTML='${i.fire}'">`:i.fire}
              </div>
              <div class="token-details">
                <div class="token-symbol">${e.token.symbol||c(e.token.address)}</div>
                <div class="token-name">${e.token.name||"Unknown"}</div>
              </div>
            </div>
            <div class="token-price">
              <span class="token-chain">${e.pair.chain}</span>
            </div>
          </div>
        `).join("")}
      </div>
    </div>
  `}function D(){return t.alerts.length===0?`
      <div class="empty-state">
        <div class="empty-icon">${i.bell}</div>
        <p>No price alerts</p>
        <p style="font-size: 11px; margin-top: 6px; color: rgba(255,255,255,0.4)">Create alerts from token overlays</p>
      </div>
    `:`
    <div class="card">
      <div class="card-body">
        ${t.alerts.map(e=>`
          <div class="alert-item">
            <div class="alert-info">
              <div class="alert-symbol">${e.symbol||c(e.address)}</div>
              <div class="alert-condition">
                ${e.type==="above"?"Above":e.type==="below"?"Below":"Change"} 
                ${e.type==="change"?`${e.value}%`:C(e.value)}
              </div>
            </div>
            <span class="alert-status ${e.triggered?"triggered":"active"}">
              ${e.triggered?"Triggered":"Active"}
            </span>
          </div>
        `).join("")}
      </div>
    </div>
  `}function B(){var e,a,n;document.querySelectorAll(".tab").forEach(r=>{r.addEventListener("click",o=>{const d=o.currentTarget.dataset.tab;t.activeTab=d,d==="trending"&&t.trending.length===0&&v(),d==="gems"&&t.gems.length===0&&g(),s()})}),(e=document.getElementById("refresh-btn"))==null||e.addEventListener("click",async()=>{t.loading=!0,s(),await f(),t.activeTab==="trending"&&await v(),t.activeTab==="gems"&&await g()}),(a=document.getElementById("settings-btn"))==null||a.addEventListener("click",()=>{var r,o;(o=(r=chrome.runtime).openOptionsPage)==null||o.call(r)}),(n=document.getElementById("dashboard-btn"))==null||n.addEventListener("click",()=>{chrome.tabs.create({url:"https://clawfi.ai"})}),document.querySelectorAll(".token-item, .gem-item").forEach(r=>{r.addEventListener("click",()=>{const o=r,p=o.dataset.url,d=o.dataset.address,b=o.dataset.chain;p?chrome.tabs.create({url:p}):d&&b&&chrome.tabs.create({url:`https://dexscreener.com/${b}/${d}`})})})}function u(){console.log("[ClawFi Popup] Initializing v0.5.0...");const e=document.createElement("style");e.textContent=$,document.head.appendChild(e),f(),g()}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",u):u();
