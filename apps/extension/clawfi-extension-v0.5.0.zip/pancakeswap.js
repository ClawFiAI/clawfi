import{i as k,u as p,t as y}from"./chunks/TokenHoverCard.js";import"./chunks/dexscreener.js";const F="0.3.1",u=/0x[a-fA-F0-9]{40}/;function $(a=48){try{return chrome.runtime.getURL(`icons/icon${a}.png`)}catch{return""}}let l=null,w="bsc",c=null,n=null,t=null;function C(){var s;const a=window.location.href.toLowerCase(),e=(s=new URLSearchParams(window.location.search).get("chain"))==null?void 0:s.toLowerCase();return e==="eth"||e==="ethereum"||e==="1"?"ethereum":e==="base"||e==="8453"?"base":e==="arb"||e==="arbitrum"||e==="42161"?"arbitrum":a.includes("chain=eth")||a.includes("chain=1")?"ethereum":a.includes("chain=base")||a.includes("chain=8453")?"base":a.includes("chain=arbitrum")||a.includes("chain=42161")?"arbitrum":"bsc"}function S(){const a=new URLSearchParams(window.location.search),i=a.get("outputCurrency");if(i&&u.test(i))return i;const e=a.get("inputCurrency");if(e&&u.test(e)&&e.toLowerCase()!=="0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee")return e;const s=window.location.pathname.match(/\/swap\/(0x[a-fA-F0-9]{40})/i);return s?s[1]:null}function x(){return`
    :host {
      all: initial;
      font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', system-ui, sans-serif;
    }
    
    * { box-sizing: border-box; margin: 0; padding: 0; }
    
    .clawfi-pcs-overlay {
      position: fixed;
      top: 80px;
      right: 20px;
      z-index: 2147483647;
      font-size: 13px;
      -webkit-font-smoothing: antialiased;
    }
    
    .clawfi-pcs-fab {
      width: 56px;
      height: 56px;
      border-radius: 16px;
      background: linear-gradient(180deg, rgba(31, 199, 212, 0.9) 0%, rgba(118, 69, 217, 0.9) 100%);
      border: 1px solid rgba(255, 255, 255, 0.25);
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 10px 40px rgba(31, 199, 212, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.3);
      transition: all 0.3s ease;
      position: relative;
    }
    
    .clawfi-pcs-fab:hover { transform: scale(1.05); }
    
    .clawfi-pcs-fab-icon {
      width: 32px;
      height: 32px;
      border-radius: 8px;
    }
    
    .clawfi-pcs-fab-badge {
      position: absolute;
      top: -4px;
      right: -4px;
      min-width: 20px;
      height: 20px;
      border-radius: 10px;
      font-size: 11px;
      font-weight: 600;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 0 5px;
    }
    
    .clawfi-pcs-fab-badge.safe { background: #30D158; color: white; }
    .clawfi-pcs-fab-badge.low { background: #0A84FF; color: white; }
    .clawfi-pcs-fab-badge.medium { background: #FFD60A; color: black; }
    .clawfi-pcs-fab-badge.high { background: #FF9F0A; color: white; }
    .clawfi-pcs-fab-badge.critical { background: #FF453A; color: white; }
    
    .clawfi-pcs-panel {
      width: 340px;
      background: rgba(20, 20, 30, 0.9);
      backdrop-filter: blur(40px);
      border-radius: 20px;
      border: 1px solid rgba(255, 255, 255, 0.15);
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
      overflow: hidden;
      animation: slideIn 0.25s ease;
    }
    
    @keyframes slideIn {
      from { opacity: 0; transform: translateY(-10px); }
      to { opacity: 1; transform: translateY(0); }
    }
    
    .clawfi-pcs-header {
      padding: 14px 16px;
      background: linear-gradient(180deg, rgba(31, 199, 212, 0.8) 0%, rgba(118, 69, 217, 0.8) 100%);
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    
    .clawfi-pcs-header-title {
      display: flex;
      align-items: center;
      gap: 8px;
      color: white;
      font-weight: 600;
      font-size: 15px;
    }
    
    .clawfi-pcs-header-logo {
      width: 22px;
      height: 22px;
      border-radius: 5px;
    }
    
    .clawfi-pcs-close {
      width: 28px;
      height: 28px;
      border-radius: 8px;
      background: rgba(255, 255, 255, 0.2);
      border: none;
      color: white;
      font-size: 16px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .clawfi-pcs-body { padding: 16px; }
    
    .clawfi-pcs-address {
      font-family: 'SF Mono', monospace;
      font-size: 11px;
      color: rgba(255, 255, 255, 0.7);
      background: rgba(255, 255, 255, 0.08);
      padding: 8px 12px;
      border-radius: 10px;
      margin-bottom: 14px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    
    .clawfi-pcs-chain-badge {
      font-size: 10px;
      padding: 3px 8px;
      border-radius: 100px;
      background: rgba(31, 199, 212, 0.3);
      color: #1FC7D4;
      border: 1px solid rgba(31, 199, 212, 0.5);
      text-transform: uppercase;
    }
    
    .clawfi-pcs-risk {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 12px 14px;
      border-radius: 12px;
      margin-bottom: 14px;
    }
    
    .clawfi-pcs-risk.safe { background: rgba(48, 209, 88, 0.15); border: 1px solid rgba(48, 209, 88, 0.3); }
    .clawfi-pcs-risk.low { background: rgba(10, 132, 255, 0.15); border: 1px solid rgba(10, 132, 255, 0.3); }
    .clawfi-pcs-risk.medium { background: rgba(255, 214, 10, 0.15); border: 1px solid rgba(255, 214, 10, 0.3); }
    .clawfi-pcs-risk.high { background: rgba(255, 159, 10, 0.15); border: 1px solid rgba(255, 159, 10, 0.3); }
    .clawfi-pcs-risk.critical { background: rgba(255, 69, 58, 0.15); border: 1px solid rgba(255, 69, 58, 0.3); }
    
    .clawfi-pcs-risk-dot {
      width: 12px;
      height: 12px;
      border-radius: 50%;
    }
    
    .clawfi-pcs-risk.safe .clawfi-pcs-risk-dot { background: #30D158; box-shadow: 0 0 10px #30D158; }
    .clawfi-pcs-risk.low .clawfi-pcs-risk-dot { background: #0A84FF; box-shadow: 0 0 10px #0A84FF; }
    .clawfi-pcs-risk.medium .clawfi-pcs-risk-dot { background: #FFD60A; box-shadow: 0 0 10px #FFD60A; }
    .clawfi-pcs-risk.high .clawfi-pcs-risk-dot { background: #FF9F0A; box-shadow: 0 0 10px #FF9F0A; }
    .clawfi-pcs-risk.critical .clawfi-pcs-risk-dot { background: #FF453A; box-shadow: 0 0 10px #FF453A; }
    
    .clawfi-pcs-risk-text { flex: 1; color: white; font-weight: 500; font-size: 14px; }
    .clawfi-pcs-risk-score { color: rgba(255, 255, 255, 0.6); font-size: 12px; }
    
    .clawfi-pcs-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 10px;
      margin-bottom: 14px;
    }
    
    .clawfi-pcs-stat {
      background: rgba(255, 255, 255, 0.05);
      border-radius: 12px;
      padding: 12px;
      border: 1px solid rgba(255, 255, 255, 0.08);
    }
    
    .clawfi-pcs-stat-label {
      font-size: 10px;
      color: rgba(255, 255, 255, 0.4);
      text-transform: uppercase;
      margin-bottom: 4px;
    }
    
    .clawfi-pcs-stat-value { font-size: 16px; font-weight: 600; color: white; }
    .clawfi-pcs-stat-sub { font-size: 11px; margin-top: 2px; }
    .clawfi-pcs-stat-sub.positive { color: #30D158; }
    .clawfi-pcs-stat-sub.negative { color: #FF453A; }
    
    .clawfi-pcs-actions { display: flex; gap: 10px; }
    
    .clawfi-pcs-btn {
      flex: 1;
      padding: 12px;
      border-radius: 12px;
      border: 1px solid rgba(255, 255, 255, 0.15);
      background: rgba(255, 255, 255, 0.08);
      color: white;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      text-align: center;
      text-decoration: none;
      transition: all 0.2s;
    }
    
    .clawfi-pcs-btn:hover { background: rgba(255, 255, 255, 0.15); }
    
    .clawfi-pcs-btn.primary {
      background: linear-gradient(135deg, rgba(31, 199, 212, 0.5) 0%, rgba(118, 69, 217, 0.5) 100%);
      border-color: rgba(31, 199, 212, 0.6);
    }
    
    .clawfi-pcs-loading {
      padding: 40px;
      text-align: center;
      color: rgba(255, 255, 255, 0.5);
    }
    
    .clawfi-pcs-spinner {
      width: 28px;
      height: 28px;
      border: 2px solid rgba(255, 255, 255, 0.1);
      border-top-color: #1FC7D4;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
      margin: 0 auto 12px;
    }
    
    @keyframes spin { to { transform: rotate(360deg); } }
    
    .clawfi-pcs-footer {
      padding: 12px 16px;
      background: rgba(0, 0, 0, 0.2);
      border-top: 1px solid rgba(255, 255, 255, 0.06);
      font-size: 11px;
      color: rgba(255, 255, 255, 0.4);
      text-align: center;
    }
  `}function b(a){return a>=1e9?(a/1e9).toFixed(2)+"B":a>=1e6?(a/1e6).toFixed(2)+"M":a>=1e3?(a/1e3).toFixed(1)+"K":a.toFixed(0)}function o(){var s;if(!n||!t)return;const a=$(32),i=((s=t.safety)==null?void 0:s.overallRisk)||"low",e=y.getRiskBadge(i);if(!t.expanded)n.innerHTML=`
      <style>${x()}</style>
      <div class="clawfi-pcs-overlay">
        <button class="clawfi-pcs-fab" id="expand-btn">
          ${a?`<img class="clawfi-pcs-fab-icon" src="${a}">`:"🦀"}
          <span class="clawfi-pcs-fab-badge ${i}">${e.emoji}</span>
        </button>
      </div>
    `;else{const{marketData:r,safety:f,chain:g}=t,v=p.getDexscreenerUrl(g,t.token);n.innerHTML=`
      <style>${x()}</style>
      <div class="clawfi-pcs-overlay">
        <div class="clawfi-pcs-panel">
          <div class="clawfi-pcs-header">
            <div class="clawfi-pcs-header-title">
              ${a?`<img class="clawfi-pcs-header-logo" src="${a}">`:"🦀"}
              ClawFi
            </div>
            <button class="clawfi-pcs-close" id="close-btn">×</button>
          </div>
          
          <div class="clawfi-pcs-body">
            ${t.loading?`
              <div class="clawfi-pcs-loading">
                <div class="clawfi-pcs-spinner"></div>
                Analyzing token...
              </div>
            `:`
              <div class="clawfi-pcs-address">
                <span>${t.token.slice(0,8)}...${t.token.slice(-6)}</span>
                <span class="clawfi-pcs-chain-badge">${g}</span>
              </div>
              
              <div class="clawfi-pcs-risk ${i}">
                <span class="clawfi-pcs-risk-dot"></span>
                <span class="clawfi-pcs-risk-text">${e.text}</span>
                <span class="clawfi-pcs-risk-score">${(f==null?void 0:f.riskScore)||0}/100</span>
              </div>
              
              ${r?`
                <div class="clawfi-pcs-grid">
                  <div class="clawfi-pcs-stat">
                    <div class="clawfi-pcs-stat-label">Price</div>
                    <div class="clawfi-pcs-stat-value">$${r.priceUsd<.01?r.priceUsd.toExponential(2):r.priceUsd.toFixed(4)}</div>
                    <div class="clawfi-pcs-stat-sub ${r.priceChange24h>=0?"positive":"negative"}">
                      ${r.priceChange24h>=0?"+":""}${r.priceChange24h.toFixed(2)}%
                    </div>
                  </div>
                  <div class="clawfi-pcs-stat">
                    <div class="clawfi-pcs-stat-label">Liquidity</div>
                    <div class="clawfi-pcs-stat-value">$${b(r.liquidity)}</div>
                  </div>
                  <div class="clawfi-pcs-stat">
                    <div class="clawfi-pcs-stat-label">Volume 24h</div>
                    <div class="clawfi-pcs-stat-value">$${b(r.volume24h)}</div>
                  </div>
                  <div class="clawfi-pcs-stat">
                    <div class="clawfi-pcs-stat-label">Market Cap</div>
                    <div class="clawfi-pcs-stat-value">${r.marketCap?"$"+b(r.marketCap):"N/A"}</div>
                  </div>
                </div>
              `:""}
              
              <div class="clawfi-pcs-actions">
                <a class="clawfi-pcs-btn" href="${v}" target="_blank">📊 Chart</a>
                <a class="clawfi-pcs-btn primary" href="${p.getSwapUrl(g,"ETH",t.token)}" target="_blank">💱 Swap</a>
              </div>
            `}
          </div>
          
          <div class="clawfi-pcs-footer">ClawFi v${F}</div>
        </div>
      </div>
    `}D()}function D(){if(!n)return;const a=n.getElementById("expand-btn");a==null||a.addEventListener("click",()=>{t&&(t.expanded=!0,o())});const i=n.getElementById("close-btn");i==null||i.addEventListener("click",()=>{t&&(t.expanded=!1,o())})}function E(){c||(c=document.createElement("div"),c.id="clawfi-pancakeswap-overlay",document.body.appendChild(c),n=c.attachShadow({mode:"closed"}))}async function A(a,i){E(),t={loading:!0,token:a,chain:i,marketData:null,safety:null,expanded:!1},o(),chrome.runtime.sendMessage({type:"DETECTED_TOKEN",token:a,chain:i,source:"pancakeswap"});try{const[e,s]=await Promise.all([p.getMarketData(a,i),p.getTokenSafety(a,i)]);t&&t.token===a&&(t.loading=!1,t.marketData=e,t.safety=s,o())}catch(e){console.error("[ClawFi PancakeSwap] Error:",e),t&&(t.loading=!1,o())}}function h(){c&&(c.remove(),c=null,n=null),t=null}function d(){const a=S(),i=C();a&&(a!==l||i!==w)?(l=a,w=i,h(),A(a,i)):!a&&l&&(l=null,h())}function z(){const a=history.pushState.bind(history),i=history.replaceState.bind(history);history.pushState=function(...e){const s=a(...e);return d(),s},history.replaceState=function(...e){const s=i(...e);return d(),s},window.addEventListener("popstate",d)}function m(){console.log("[ClawFi] PancakeSwap content script loaded"),k(),z(),d()}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",m):m();
