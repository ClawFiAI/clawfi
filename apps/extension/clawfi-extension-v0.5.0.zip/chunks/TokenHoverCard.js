var be=Object.defineProperty;var ve=(a,r,t)=>r in a?be(a,r,{enumerable:!0,configurable:!0,writable:!0,value:t}):a[r]=t;var le=(a,r,t)=>ve(a,typeof r!="symbol"?r+"":r,t);import{C as B,d as F}from"./dexscreener.js";const g="https://api.geckoterminal.com/api/v2",de=new Map,xe=6e4;async function w(a,r=xe){const t=de.get(a);if(t&&Date.now()-t.timestamp<r)return t.data;const e=new AbortController,o=setTimeout(()=>e.abort(),1e4);try{const s=await fetch(a,{headers:{Accept:"application/json"},signal:e.signal});if(clearTimeout(o),!s.ok)throw s.status===429?new Error("GeckoTerminal rate limit exceeded"):new Error(`GeckoTerminal API error: ${s.status}`);const n=await s.json();return de.set(a,{data:n,timestamp:Date.now()}),n}catch(s){throw clearTimeout(o),s}}function y(a){var r;return((r=B[a])==null?void 0:r.geckoTerminalId)||a}function x(a,r,t){var d,c,p,u,f,h,z,K,V,O,J,Q,W,Y,X,Z,ee,te,re,oe,se,ae,ne,ie,ce;const e=a.attributes,o=a.relationships.base_token.data.id,s=a.relationships.quote_token.data.id,n=t==null?void 0:t.find(C=>C.type==="token"&&C.id===o),i=t==null?void 0:t.find(C=>C.type==="token"&&C.id===s),l=((d=Object.values(B).find(C=>C.geckoTerminalId===r))==null?void 0:d.id)||r;return{address:e.address,chain:l,dex:a.relationships.dex.data.id.replace(`${r}_`,""),baseToken:{address:(n==null?void 0:n.attributes.address)||o.split("_").pop()||"",name:(n==null?void 0:n.attributes.name)||"",symbol:(n==null?void 0:n.attributes.symbol)||"",decimals:(n==null?void 0:n.attributes.decimals)||18,logoUrl:n==null?void 0:n.attributes.image_url,chain:l},quoteToken:{address:(i==null?void 0:i.attributes.address)||s.split("_").pop()||"",name:(i==null?void 0:i.attributes.name)||"",symbol:(i==null?void 0:i.attributes.symbol)||"",decimals:(i==null?void 0:i.attributes.decimals)||18,logoUrl:i==null?void 0:i.attributes.image_url,chain:l},priceUsd:parseFloat(e.base_token_price_usd)||0,priceNative:parseFloat(e.base_token_price_native_currency)||0,priceChange:{m5:parseFloat((c=e.price_change_percentage)==null?void 0:c.m5)||0,h1:parseFloat((p=e.price_change_percentage)==null?void 0:p.h1)||0,h6:parseFloat((u=e.price_change_percentage)==null?void 0:u.h6)||0,h24:parseFloat((f=e.price_change_percentage)==null?void 0:f.h24)||0},volume:{m5:parseFloat((h=e.volume_usd)==null?void 0:h.m5)||0,h1:parseFloat((z=e.volume_usd)==null?void 0:z.h1)||0,h6:parseFloat((K=e.volume_usd)==null?void 0:K.h6)||0,h24:parseFloat((V=e.volume_usd)==null?void 0:V.h24)||0},txns:{m5:{buys:((J=(O=e.transactions)==null?void 0:O.m5)==null?void 0:J.buys)||0,sells:((W=(Q=e.transactions)==null?void 0:Q.m5)==null?void 0:W.sells)||0},h1:{buys:((X=(Y=e.transactions)==null?void 0:Y.h1)==null?void 0:X.buys)||0,sells:((ee=(Z=e.transactions)==null?void 0:Z.h1)==null?void 0:ee.sells)||0},h6:{buys:((re=(te=e.transactions)==null?void 0:te.h6)==null?void 0:re.buys)||0,sells:((se=(oe=e.transactions)==null?void 0:oe.h6)==null?void 0:se.sells)||0},h24:{buys:((ne=(ae=e.transactions)==null?void 0:ae.h24)==null?void 0:ne.buys)||0,sells:((ce=(ie=e.transactions)==null?void 0:ie.h24)==null?void 0:ce.sells)||0}},liquidity:{usd:parseFloat(e.reserve_in_usd)||0,base:0,quote:0},fdv:parseFloat(e.fdv_usd)||void 0,marketCap:e.market_cap_usd?parseFloat(e.market_cap_usd):void 0,pairCreatedAt:e.pool_created_at?new Date(e.pool_created_at).getTime():void 0,url:`https://www.geckoterminal.com/${r}/pools/${e.address}`}}class Te{async getNetworks(){try{return(await w(`${g}/networks`,3e5)).data.map(t=>({id:t.id,name:t.attributes.name}))}catch(r){return console.error("[GeckoTerminal] getNetworks error:",r),[]}}async getTrendingPools(r=1){try{const t=await w(`${g}/networks/trending_pools?page=${r}`,12e4);return t.data.map((e,o)=>{const s=e.id.split("_")[0],n=x(e,s,t.included);return{token:n.baseToken,pair:n,rank:(r-1)*20+o+1,source:"geckoterminal"}})}catch(t){return console.error("[GeckoTerminal] getTrendingPools error:",t),[]}}async getTrendingPoolsByNetwork(r,t=1){try{const e=y(r),o=await w(`${g}/networks/${e}/trending_pools?page=${t}`,12e4);return o.data.map((s,n)=>{const i=x(s,e,o.included);return{token:i.baseToken,pair:i,rank:(t-1)*20+n+1,source:"geckoterminal"}})}catch(e){return console.error("[GeckoTerminal] getTrendingPoolsByNetwork error:",e),[]}}async getNewPools(r,t=1){try{const e=y(r),o=await w(`${g}/networks/${e}/new_pools?page=${t}`,6e4);return o.data.map(s=>{const n=x(s,e,o.included);return{pair:n,createdAt:n.pairCreatedAt||Date.now(),initialLiquidity:n.liquidity.usd,currentLiquidity:n.liquidity.usd}})}catch(e){return console.error("[GeckoTerminal] getNewPools error:",e),[]}}async getPool(r,t){try{const e=y(r),o=await w(`${g}/networks/${e}/pools/${t}`);return x(o.data,e,o.included)}catch(e){return console.error("[GeckoTerminal] getPool error:",e),null}}async getMultiplePools(r,t){try{const e=y(r),o=t.slice(0,30).join(","),s=await w(`${g}/networks/${e}/pools/multi/${o}`);return s.data.map(n=>x(n,e,s.included))}catch(e){return console.error("[GeckoTerminal] getMultiplePools error:",e),[]}}async getTopPools(r,t=1){try{const e=y(r),o=await w(`${g}/networks/${e}/pools?page=${t}`,12e4);return o.data.map(s=>x(s,e,o.included))}catch(e){return console.error("[GeckoTerminal] getTopPools error:",e),[]}}async getTokenPools(r,t,e=1){try{const o=y(r),s=await w(`${g}/networks/${o}/tokens/${t}/pools?page=${e}`);return s.data.map(n=>x(n,o,s.included))}catch(o){return console.error("[GeckoTerminal] getTokenPools error:",o),[]}}async getToken(r,t){try{const e=y(r),s=(await w(`${g}/networks/${e}/tokens/${t}`)).data.attributes,n=Object.values(B).find(i=>i.geckoTerminalId===e);return{address:s.address,name:s.name,symbol:s.symbol,decimals:s.decimals,logoUrl:s.image_url,chain:(n==null?void 0:n.id)||e}}catch(e){return console.error("[GeckoTerminal] getToken error:",e),null}}async getTokenPrice(r,t){try{const e=y(r),n=(await w(`${g}/simple/networks/${e}/token_price/${t}`)).data.attributes.token_prices[t.toLowerCase()];return n?parseFloat(n):null}catch(e){return console.error("[GeckoTerminal] getTokenPrice error:",e),null}}async searchPools(r,t,e=1){try{let o=`${g}/search/pools?query=${encodeURIComponent(r)}&page=${e}`;if(t){const n=y(t);o+=`&network=${n}`}const s=await w(o);return s.data.map(n=>{const i=n.id.split("_")[0];return x(n,i,s.included)})}catch(o){return console.error("[GeckoTerminal] searchPools error:",o),[]}}async getPoolOHLCV(r,t,e="hour",o=1,s=100){try{const n=y(r);return(await w(`${g}/networks/${n}/pools/${t}/ohlcv/${e}?aggregate=${o}&limit=${s}`)).data.attributes.ohlcv_list.map(([l,d,c,p,u,f])=>({timestamp:l*1e3,open:d,high:c,low:p,close:u,volume:f}))}catch(n){return console.error("[GeckoTerminal] getPoolOHLCV error:",n),[]}}}const _=new Te,H="https://api.jup.ag/price/v2",$e="https://api.jup.ag/swap/v1",pe="https://tokens.jup.ag",ue=new Map,Ce=15e3;async function S(a,r=Ce){const t=ue.get(a);if(t&&Date.now()-t.timestamp<r)return t.data;const e=await fetch(a,{headers:{Accept:"application/json"}});if(!e.ok)throw new Error(`Jupiter API error: ${e.status}`);const o=await e.json();return ue.set(a,{data:o,timestamp:Date.now()}),o}class Pe{async getPrice(r){try{const e=(await S(`${H}?ids=${r}`)).data[r];return e?parseFloat(e.price):null}catch(t){return console.error("[Jupiter] getPrice error:",t),null}}async getPrices(r){const t=new Map;try{const e=[];for(let o=0;o<r.length;o+=100)e.push(r.slice(o,o+100));for(const o of e){const s=await S(`${H}?ids=${o.join(",")}`);for(const[n,i]of Object.entries(s.data))i&&i.price&&t.set(n,parseFloat(i.price))}}catch(e){console.error("[Jupiter] getPrices error:",e)}return t}async getPriceWithDetails(r){var t,e,o,s,n,i,l,d,c,p,u;try{const h=(await S(`${H}?ids=${r}&showExtraInfo=true`)).data[r];return h?{price:parseFloat(h.price),confidence:((t=h.extraInfo)==null?void 0:t.confidenceLevel)||"unknown",buyPrice:(o=(e=h.extraInfo)==null?void 0:e.quotedPrice)!=null&&o.buyPrice?parseFloat(h.extraInfo.quotedPrice.buyPrice):void 0,sellPrice:(n=(s=h.extraInfo)==null?void 0:s.quotedPrice)!=null&&n.sellPrice?parseFloat(h.extraInfo.quotedPrice.sellPrice):void 0,depthBuy:(d=(l=(i=h.extraInfo)==null?void 0:i.depth)==null?void 0:l.buyPriceImpactRatio)==null?void 0:d.depth,depthSell:(u=(p=(c=h.extraInfo)==null?void 0:c.depth)==null?void 0:p.sellPriceImpactRatio)==null?void 0:u.depth}:null}catch(f){return console.error("[Jupiter] getPriceWithDetails error:",f),null}}async getQuote(r,t,e,o=50){try{const s=await fetch(`${$e}/quote?inputMint=${r}&outputMint=${t}&amount=${e}&slippageBps=${o}`);if(!s.ok)throw new Error(`Quote failed: ${s.status}`);const n=await s.json(),[i,l]=await Promise.all([this.getTokenInfo(r),this.getTokenInfo(t)]),d=n.routePlan.map(c=>({dex:c.swapInfo.label,poolAddress:c.swapInfo.ammKey,inputToken:c.swapInfo.inputMint,outputToken:c.swapInfo.outputMint}));return{inputToken:i||{address:r,name:"Unknown",symbol:"UNK",decimals:9,chain:"solana"},outputToken:l||{address:t,name:"Unknown",symbol:"UNK",decimals:9,chain:"solana"},inputAmount:n.inAmount,outputAmount:n.outAmount,priceImpact:parseFloat(n.priceImpactPct),route:d,provider:"jupiter"}}catch(s){return console.error("[Jupiter] getQuote error:",s),null}}async getVerifiedTokens(){try{return await S(`${pe}/tokens?tags=verified`,3e5)}catch(r){return console.error("[Jupiter] getVerifiedTokens error:",r),[]}}async getStrictTokens(){try{return await S(`${pe}/tokens_with_markets`,3e5)}catch(r){return console.error("[Jupiter] getStrictTokens error:",r),[]}}async getTokenInfo(r){try{const e=(await this.getVerifiedTokens()).find(n=>n.address===r);if(e)return{address:e.address,name:e.name,symbol:e.symbol,decimals:e.decimals,logoUrl:e.logoURI,chain:"solana"};const s=(await this.getStrictTokens()).find(n=>n.address===r);return s?{address:s.address,name:s.name,symbol:s.symbol,decimals:s.decimals,logoUrl:s.logoURI,chain:"solana"}:null}catch(t){return console.error("[Jupiter] getTokenInfo error:",t),null}}async searchTokens(r){try{const t=await this.getVerifiedTokens(),e=r.toLowerCase();return t.filter(o=>o.name.toLowerCase().includes(e)||o.symbol.toLowerCase().includes(e)||o.address.toLowerCase()===e).slice(0,20).map(o=>({address:o.address,name:o.name,symbol:o.symbol,decimals:o.decimals,logoUrl:o.logoURI,chain:"solana"}))}catch(t){return console.error("[Jupiter] searchTokens error:",t),[]}}async isVerified(r){try{return(await this.getVerifiedTokens()).some(e=>e.address===r)}catch{return!1}}async getTokenMarketData(r){try{const[t,e]=await Promise.all([this.getPriceWithDetails(r),this.getTokenInfo(r)]);return t?{priceUsd:t.price,priceChange24h:0,priceChangeH1:0,priceChangeM5:0,volume24h:0,volumeH1:0,liquidity:0,dex:"Jupiter",pairAddress:r,pairUrl:`https://jup.ag/swap/SOL-${r}`,txns24h:{buys:0,sells:0},txnsH1:{buys:0,sells:0}}:null}catch(t){return console.error("[Jupiter] getTokenMarketData error:",t),null}}buildSwapUrl(r,t){return`https://jup.ag/swap/${r}-${t}`}async getPriceImpact(r,t,e){const o=await this.getQuote(r,t,e);return(o==null?void 0:o.priceImpact)??null}}const U=new Pe,Ie={ethereum:1,base:8453,arbitrum:42161,optimism:10,polygon:137,bsc:56,avalanche:43114,fantom:250,gnosis:100,solana:null,sui:null,aptos:null,cronos:25,moonbeam:1284,celo:42220},P="https://api.1inch.dev/swap/v6.0",he=new Map,Ae=3e4;async function I(a,r,t=Ae){const e=he.get(a);if(e&&Date.now()-e.timestamp<t)return e.data;const o={Accept:"application/json"};r&&(o.Authorization=`Bearer ${r}`);const s=await fetch(a,{headers:o});if(!s.ok)throw s.status===429?new Error("1inch rate limit exceeded"):new Error(`1inch API error: ${s.status}`);const n=await s.json();return he.set(a,{data:n,timestamp:Date.now()}),n}function k(a){return Ie[a]}function Fe(a){return k(a)!==null}class Se{constructor(r){le(this,"apiKey");this.apiKey=r}setApiKey(r){this.apiKey=r}isChainSupported(r){return Fe(r)}async getTokens(r){const t=k(r);if(!t)return[];try{const e=await I(`${P}/${t}/tokens`,this.apiKey,3e5);return Object.values(e.tokens).map(o=>({address:o.address,name:o.name,symbol:o.symbol,decimals:o.decimals,logoUrl:o.logoURI,chain:r}))}catch(e){return console.error("[1inch] getTokens error:",e),[]}}async getQuote(r,t,e,o,s=1){const n=k(r);if(!n)return null;try{const i=new URLSearchParams({src:t,dst:e,amount:o,includeProtocols:"true"}),l=await I(`${P}/${n}/quote?${i}`,this.apiKey,15e3),d=[];for(const c of l.protocols)for(const p of c)for(const u of p)d.push({dex:u.name,poolAddress:"",inputToken:u.fromTokenAddress,outputToken:u.toTokenAddress});return{inputToken:{address:l.srcToken.address,name:l.srcToken.name,symbol:l.srcToken.symbol,decimals:l.srcToken.decimals,logoUrl:l.srcToken.logoURI,chain:r},outputToken:{address:l.dstToken.address,name:l.dstToken.name,symbol:l.dstToken.symbol,decimals:l.dstToken.decimals,logoUrl:l.dstToken.logoURI,chain:r},inputAmount:o,outputAmount:l.dstAmount,priceImpact:0,route:d,estimatedGas:l.gas.toString(),provider:"1inch"}}catch(i){return console.error("[1inch] getQuote error:",i),null}}async getSwap(r,t,e,o,s,n=1){const i=k(r);if(!i)return null;try{const l=new URLSearchParams({src:t,dst:e,amount:o,from:s,slippage:n.toString(),includeProtocols:"true",disableEstimate:"true"}),d=await fetch(`${P}/${i}/swap?${l}`,{headers:this.apiKey?{Authorization:`Bearer ${this.apiKey}`,Accept:"application/json"}:{Accept:"application/json"}});if(!d.ok)throw new Error(`Swap failed: ${d.status}`);const c=await d.json(),p=[];for(const u of c.protocols)for(const f of u)for(const h of f)p.push({dex:h.name,poolAddress:"",inputToken:h.fromTokenAddress,outputToken:h.toTokenAddress});return{quote:{inputToken:{address:c.srcToken.address,name:c.srcToken.name,symbol:c.srcToken.symbol,decimals:c.srcToken.decimals,logoUrl:c.srcToken.logoURI,chain:r},outputToken:{address:c.dstToken.address,name:c.dstToken.name,symbol:c.dstToken.symbol,decimals:c.dstToken.decimals,logoUrl:c.dstToken.logoURI,chain:r},inputAmount:o,outputAmount:c.dstAmount,priceImpact:0,route:p,estimatedGas:c.tx.gas.toString(),provider:"1inch"},txData:{to:c.tx.to,data:c.tx.data,value:c.tx.value,gasPrice:c.tx.gasPrice,gas:c.tx.gas}}}catch(l){return console.error("[1inch] getSwap error:",l),null}}async getAllowance(r,t,e){const o=k(r);if(!o)return null;try{return(await I(`${P}/${o}/approve/allowance?tokenAddress=${t}&walletAddress=${e}`,this.apiKey)).allowance}catch(s){return console.error("[1inch] getAllowance error:",s),null}}async getApprovalTx(r,t,e){const o=k(r);if(!o)return null;try{const s=new URLSearchParams({tokenAddress:t});e&&s.set("amount",e);const n=await I(`${P}/${o}/approve/transaction?${s}`,this.apiKey);return{to:n.to,data:n.data,value:n.value}}catch(s){return console.error("[1inch] getApprovalTx error:",s),null}}async getRouterAddress(r){const t=k(r);if(!t)return null;try{return(await I(`${P}/${t}/approve/spender`,this.apiKey,36e5)).address}catch(e){return console.error("[1inch] getRouterAddress error:",e),null}}buildSwapUrl(r,t,e){const o=k(r);return o?`https://app.1inch.io/#/${o}/simple/swap/${t}/${e}`:"https://app.1inch.io/"}async getLiquiditySources(r){const t=k(r);if(!t)return[];try{return(await I(`${P}/${t}/liquidity-sources`,this.apiKey,36e5)).protocols.map(o=>o.id)}catch(e){return console.error("[1inch] getLiquiditySources error:",e),[]}}}const fe=new Se,T={honeypot:40,lowLiquidity:15,concentratedHolders:20,newToken:10},A={minLiquidity:1e4,lowLiquidity:5e4,safeLiquidity:25e4,concentrationThreshold:50,highConcentration:70,newTokenHours:24};async function Le(a,r){try{const t=await F.getTokenPairs(r,a);if(t.length===0)return{isHoneypot:!1,buyTax:0,sellTax:0,transferTax:0,reason:"No trading data available"};const e=t.sort((p,u)=>u.liquidity.usd-p.liquidity.usd)[0],{buys:o,sells:s}=e.txns.h24,n=o+s;if(n>50&&s/n<.05)return{isHoneypot:!0,buyTax:0,sellTax:100,transferTax:0,reason:"Extreme buy/sell imbalance - possible honeypot"};const{m5:i,h1:l,h6:d,h24:c}=e.priceChange;return i>0&&l>0&&d>0&&c>0&&c>50&&s<5&&o>100?{isHoneypot:!0,buyTax:0,sellTax:100,transferTax:0,reason:"No successful sells detected"}:{isHoneypot:!1,buyTax:0,sellTax:0,transferTax:0}}catch(t){return console.error("[Safety] checkHoneypot error:",t),{isHoneypot:!1,buyTax:0,sellTax:0,transferTax:0,reason:"Unable to check"}}}async function _e(a,r){try{const t=await F.getTokenPairs(r,a);if(t.length===0)return{isConcentrated:!0,estimatedTop10Percent:80};const e=t[0],{buys:o,sells:s}=e.txns.h24;return o+s<50&&e.volume.h24>1e5?{isConcentrated:!0,estimatedTop10Percent:70}:{isConcentrated:!1,estimatedTop10Percent:40}}catch{return{isConcentrated:!1,estimatedTop10Percent:50}}}class Ue{async analyze(r,t){const e=[];let o=0;const s=await F.getTokenMarketData(t,r),n=await Le(r,t);n.isHoneypot?(e.push({name:"Honeypot Detection",passed:!1,severity:"critical",details:n.reason||"Token appears to be a honeypot - selling may be impossible"}),o+=T.honeypot):e.push({name:"Honeypot Detection",passed:!0,severity:"safe",details:"No honeypot patterns detected"});const i=(s==null?void 0:s.liquidity)||0;i<A.minLiquidity?(e.push({name:"Liquidity",passed:!1,severity:"critical",details:`Extremely low liquidity: $${i.toLocaleString()}. High slippage and rug risk.`}),o+=T.lowLiquidity):i<A.lowLiquidity?(e.push({name:"Liquidity",passed:!1,severity:"high",details:`Low liquidity: $${i.toLocaleString()}. May experience high slippage.`}),o+=T.lowLiquidity*.6):i<A.safeLiquidity?(e.push({name:"Liquidity",passed:!0,severity:"medium",details:`Moderate liquidity: $${i.toLocaleString()}`}),o+=T.lowLiquidity*.3):e.push({name:"Liquidity",passed:!0,severity:"safe",details:`Good liquidity: $${i.toLocaleString()}`});const l=await _e(r,t);if(l.isConcentrated||l.estimatedTop10Percent>A.highConcentration?(e.push({name:"Holder Distribution",passed:!1,severity:"high",details:`Estimated ${l.estimatedTop10Percent}% held by top wallets. High dump risk.`}),o+=T.concentratedHolders):l.estimatedTop10Percent>A.concentrationThreshold?(e.push({name:"Holder Distribution",passed:!1,severity:"medium",details:`Estimated ${l.estimatedTop10Percent}% held by top wallets. Moderate concentration.`}),o+=T.concentratedHolders*.5):e.push({name:"Holder Distribution",passed:!0,severity:"safe",details:"Token appears to have reasonable distribution"}),s!=null&&s.createdAt){const c=(Date.now()-s.createdAt)/36e5;c<1?(e.push({name:"Token Age",passed:!1,severity:"high",details:"Token is less than 1 hour old. Extremely high risk."}),o+=T.newToken):c<A.newTokenHours?(e.push({name:"Token Age",passed:!1,severity:"medium",details:`Token is ${Math.floor(c)} hours old. New tokens carry higher risk.`}),o+=T.newToken*.5):e.push({name:"Token Age",passed:!0,severity:"safe",details:`Token has been trading for ${Math.floor(c/24)} days`})}if(s){const c=s.volume24h/(s.liquidity||1);c>10?e.push({name:"Trading Volume",passed:!0,severity:"safe",details:`High trading activity. Volume/Liquidity ratio: ${c.toFixed(1)}x`}):c>1?e.push({name:"Trading Volume",passed:!0,severity:"low",details:`Moderate trading activity. Volume/Liquidity ratio: ${c.toFixed(1)}x`}):(e.push({name:"Trading Volume",passed:!1,severity:"medium",details:`Low trading activity. Volume/Liquidity ratio: ${c.toFixed(2)}x`}),o+=5)}if(s){const{buys:c,sells:p}=s.txns24h,u=c+p;if(u>0){const f=c/u;f>.9?(e.push({name:"Buy/Sell Balance",passed:!1,severity:"high",details:`${(f*100).toFixed(0)}% buys - extremely one-sided. Possible manipulation.`}),o+=10):f>.75||f<.25?(e.push({name:"Buy/Sell Balance",passed:!1,severity:"medium",details:`Imbalanced trading: ${c} buys vs ${p} sells`}),o+=5):e.push({name:"Buy/Sell Balance",passed:!0,severity:"safe",details:`Balanced trading: ${c} buys, ${p} sells`})}}let d;return o>=60||n.isHoneypot?d="critical":o>=40?d="high":o>=25?d="medium":o>=10?d="low":d="safe",{overallRisk:d,riskScore:Math.min(100,o),checks:e,honeypot:{isHoneypot:n.isHoneypot,buyTax:n.buyTax,sellTax:n.sellTax,transferTax:n.transferTax},holders:{total:0,top10Percentage:l.estimatedTop10Percent,isConcentrated:l.isConcentrated},liquidity:{locked:!1,lockDuration:void 0,lockPercentage:void 0},contract:{verified:!1,renounced:!1,hasProxy:!1,hasMint:!1,hasBlacklist:!1}}}async getQuickRiskScore(r,t){return(await this.analyze(r,t)).riskScore}getRiskBadge(r){switch(r){case"safe":return{text:"Safe",color:"#30D158",emoji:"✓"};case"low":return{text:"Low Risk",color:"#0A84FF",emoji:"○"};case"medium":return{text:"Medium Risk",color:"#FFD60A",emoji:"⚠"};case"high":return{text:"High Risk",color:"#FF9F0A",emoji:"⚠"};case"critical":return{text:"Critical",color:"#FF453A",emoji:"✕"}}}}const j=new Ue;class De{async getMarketData(r,t){const e=await F.getTokenMarketData(r,t);if(e)return e;const o=await _.getTokenPools(t,r);if(o.length>0){const s=o.sort((n,i)=>i.liquidity.usd-n.liquidity.usd)[0];return{priceUsd:s.priceUsd,priceChange24h:s.priceChange.h24,priceChangeH1:s.priceChange.h1,priceChangeM5:s.priceChange.m5,volume24h:s.volume.h24,volumeH1:s.volume.h1,liquidity:s.liquidity.usd,marketCap:s.marketCap,fdv:s.fdv,txns24h:s.txns.h24,txnsH1:s.txns.h1,dex:s.dex,pairAddress:s.address,pairUrl:s.url,createdAt:s.pairCreatedAt}}return t==="solana"?await U.getTokenMarketData(r):null}async getTrending(r){const t=[];try{if(r){const o=await _.getTrendingPoolsByNetwork(r);t.push(...o)}else{const o=await F.getBoostedTokens();t.push(...o);const s=await _.getTrendingPools();t.push(...s)}}catch(o){console.error("[UnifiedData] getTrending error:",o)}const e=new Set;return t.filter(o=>{const s=`${o.token.chain}:${o.token.address}`.toLowerCase();return e.has(s)?!1:(e.add(s),!0)})}async getNewPools(r){return _.getNewPools(r)}async search(r,t){const e=[],o=await F.searchPairs(r);for(const n of o)(!t||n.chain===t)&&e.push(n.baseToken);if(!t||t==="solana"){const n=await U.searchTokens(r);e.push(...n)}const s=new Set;return e.filter(n=>{const i=`${n.chain}:${n.address}`.toLowerCase();return s.has(i)?!1:(s.add(i),!0)})}async getSwapQuote(r,t,e,o,s){return r==="solana"?U.getQuote(t,e,o,s?s*100:50):fe.getQuote(r,t,e,o,s||1)}async getTokenSafety(r,t){return j.analyze(t,r)}async getRiskScore(r,t){return j.getQuickRiskScore(t,r)}getSwapUrl(r,t,e){return r==="solana"?U.buildSwapUrl(t,e):fe.buildSwapUrl(r,t,e)}getDexSwapUrl(r,t){const e={};switch(r){case"ethereum":e.uniswap=`https://app.uniswap.org/swap?chain=mainnet&outputCurrency=${t}`;break;case"base":e.uniswap=`https://app.uniswap.org/swap?chain=base&outputCurrency=${t}`;break;case"arbitrum":e.uniswap=`https://app.uniswap.org/swap?chain=arbitrum&outputCurrency=${t}`;break;case"bsc":e.pancakeswap=`https://pancakeswap.finance/swap?chain=bsc&outputCurrency=${t}`;break;case"solana":e.jupiter=`https://jup.ag/swap/SOL-${t}`,e.raydium=`https://raydium.io/swap/?inputCurrency=sol&outputCurrency=${t}`;break}return e}getExplorerUrl(r,t){const e={ethereum:"https://etherscan.io/token/",base:"https://basescan.org/token/",arbitrum:"https://arbiscan.io/token/",optimism:"https://optimistic.etherscan.io/token/",polygon:"https://polygonscan.com/token/",bsc:"https://bscscan.com/token/",avalanche:"https://snowtrace.io/token/",solana:"https://solscan.io/token/",fantom:"https://ftmscan.com/token/"};return`${e[r]||e.ethereum}${t}`}getDexscreenerUrl(r,t){return`https://dexscreener.com/${r}/${t}`}getGeckoTerminalUrl(r,t){return`https://www.geckoterminal.com/${{ethereum:"eth",base:"base",arbitrum:"arbitrum",bsc:"bsc",solana:"solana",polygon:"polygon_pos"}[r]||r}/tokens/${t}`}}const D=new De,me=300,ye=200,M=320,ge=200,N=/0x[a-fA-F0-9]{40}/,G=/[1-9A-HJ-NP-Za-km-z]{32,44}/;let $=null,v=null,m=null,b=null,L=null;function He(a=48){try{return chrome.runtime.getURL(`icons/icon${a}.png`)}catch{return""}}function q(){return`
    :host {
      all: initial;
      font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', system-ui, sans-serif;
    }
    
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    
    .clawfi-hover-card {
      position: fixed;
      width: ${M}px;
      background: rgba(30, 30, 40, 0.85);
      backdrop-filter: blur(40px) saturate(180%);
      -webkit-backdrop-filter: blur(40px) saturate(180%);
      border-radius: 16px;
      border: 1px solid rgba(255, 255, 255, 0.15);
      box-shadow: 
        0 20px 60px rgba(0, 0, 0, 0.5),
        0 8px 24px rgba(0, 0, 0, 0.3);
      z-index: 2147483647;
      overflow: hidden;
      animation: fadeIn 0.2s ease;
      pointer-events: auto;
    }
    
    @keyframes fadeIn {
      from { opacity: 0; transform: scale(0.95) translateY(-5px); }
      to { opacity: 1; transform: scale(1) translateY(0); }
    }
    
    .clawfi-hover-header {
      padding: 12px 14px;
      background: linear-gradient(180deg, rgba(10, 132, 255, 0.8) 0%, rgba(10, 100, 200, 0.85) 100%);
      display: flex;
      align-items: center;
      gap: 10px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    .clawfi-hover-logo {
      width: 24px;
      height: 24px;
      border-radius: 6px;
    }
    
    .clawfi-hover-title {
      font-size: 14px;
      font-weight: 600;
      color: white;
      flex: 1;
    }
    
    .clawfi-hover-chain {
      font-size: 11px;
      padding: 3px 8px;
      border-radius: 100px;
      background: rgba(255, 255, 255, 0.2);
      color: white;
    }
    
    .clawfi-hover-body {
      padding: 12px 14px;
    }
    
    .clawfi-hover-address {
      font-family: 'SF Mono', Menlo, monospace;
      font-size: 11px;
      color: rgba(255, 255, 255, 0.7);
      background: rgba(255, 255, 255, 0.08);
      padding: 6px 10px;
      border-radius: 8px;
      margin-bottom: 12px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      cursor: pointer;
    }
    
    .clawfi-hover-address:hover {
      background: rgba(255, 255, 255, 0.12);
    }
    
    .clawfi-hover-copy {
      font-size: 12px;
      opacity: 0.6;
    }
    
    .clawfi-hover-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 8px;
      margin-bottom: 12px;
    }
    
    .clawfi-hover-stat {
      background: rgba(255, 255, 255, 0.05);
      border-radius: 10px;
      padding: 10px 12px;
      border: 1px solid rgba(255, 255, 255, 0.06);
    }
    
    .clawfi-hover-stat-label {
      font-size: 10px;
      color: rgba(255, 255, 255, 0.4);
      text-transform: uppercase;
      margin-bottom: 4px;
    }
    
    .clawfi-hover-stat-value {
      font-size: 15px;
      font-weight: 600;
      color: white;
    }
    
    .clawfi-hover-stat-sub {
      font-size: 11px;
      margin-top: 2px;
    }
    
    .clawfi-hover-stat-sub.positive { color: #30D158; }
    .clawfi-hover-stat-sub.negative { color: #FF453A; }
    
    .clawfi-hover-risk {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 10px 12px;
      border-radius: 10px;
      margin-bottom: 12px;
    }
    
    .clawfi-hover-risk.safe {
      background: rgba(48, 209, 88, 0.15);
      border: 1px solid rgba(48, 209, 88, 0.3);
    }
    
    .clawfi-hover-risk.low {
      background: rgba(10, 132, 255, 0.15);
      border: 1px solid rgba(10, 132, 255, 0.3);
    }
    
    .clawfi-hover-risk.medium {
      background: rgba(255, 214, 10, 0.15);
      border: 1px solid rgba(255, 214, 10, 0.3);
    }
    
    .clawfi-hover-risk.high {
      background: rgba(255, 159, 10, 0.15);
      border: 1px solid rgba(255, 159, 10, 0.3);
    }
    
    .clawfi-hover-risk.critical {
      background: rgba(255, 69, 58, 0.15);
      border: 1px solid rgba(255, 69, 58, 0.3);
    }
    
    .clawfi-hover-risk-dot {
      width: 10px;
      height: 10px;
      border-radius: 50%;
    }
    
    .clawfi-hover-risk.safe .clawfi-hover-risk-dot { background: #30D158; box-shadow: 0 0 8px #30D158; }
    .clawfi-hover-risk.low .clawfi-hover-risk-dot { background: #0A84FF; box-shadow: 0 0 8px #0A84FF; }
    .clawfi-hover-risk.medium .clawfi-hover-risk-dot { background: #FFD60A; box-shadow: 0 0 8px #FFD60A; }
    .clawfi-hover-risk.high .clawfi-hover-risk-dot { background: #FF9F0A; box-shadow: 0 0 8px #FF9F0A; }
    .clawfi-hover-risk.critical .clawfi-hover-risk-dot { background: #FF453A; box-shadow: 0 0 8px #FF453A; }
    
    .clawfi-hover-risk-text {
      font-size: 13px;
      font-weight: 500;
      color: white;
      flex: 1;
    }
    
    .clawfi-hover-risk-score {
      font-size: 11px;
      color: rgba(255, 255, 255, 0.6);
    }
    
    .clawfi-hover-actions {
      display: flex;
      gap: 8px;
    }
    
    .clawfi-hover-btn {
      flex: 1;
      padding: 10px;
      border-radius: 10px;
      border: 1px solid rgba(255, 255, 255, 0.15);
      background: rgba(255, 255, 255, 0.08);
      color: white;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      text-decoration: none;
      text-align: center;
      transition: all 0.2s ease;
    }
    
    .clawfi-hover-btn:hover {
      background: rgba(255, 255, 255, 0.15);
      transform: translateY(-1px);
    }
    
    .clawfi-hover-btn.primary {
      background: rgba(10, 132, 255, 0.5);
      border-color: rgba(10, 132, 255, 0.6);
    }
    
    .clawfi-hover-btn.primary:hover {
      background: rgba(10, 132, 255, 0.7);
    }
    
    .clawfi-hover-loading {
      padding: 40px;
      text-align: center;
      color: rgba(255, 255, 255, 0.5);
    }
    
    .clawfi-hover-spinner {
      width: 24px;
      height: 24px;
      border: 2px solid rgba(255, 255, 255, 0.1);
      border-top-color: #0A84FF;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
      margin: 0 auto 12px;
    }
    
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
    
    .clawfi-hover-error {
      padding: 20px;
      text-align: center;
      color: rgba(255, 255, 255, 0.5);
      font-size: 13px;
    }
  `}function E(a){return a>=1e9?(a/1e9).toFixed(2)+"B":a>=1e6?(a/1e6).toFixed(2)+"M":a>=1e3?(a/1e3).toFixed(1)+"K":a.toFixed(0)}function R(a){const r=He(24);if(a.loading)return`
      <div class="clawfi-hover-card" style="top: ${a.position.y}px; left: ${a.position.x}px;">
        <div class="clawfi-hover-header">
          ${r?`<img class="clawfi-hover-logo" src="${r}" alt="">`:"<span>🦀</span>"}
          <span class="clawfi-hover-title">ClawFi</span>
          <span class="clawfi-hover-chain">${a.chain}</span>
        </div>
        <div class="clawfi-hover-loading">
          <div class="clawfi-hover-spinner"></div>
          Loading token data...
        </div>
      </div>
    `;if(!a.marketData)return`
      <div class="clawfi-hover-card" style="top: ${a.position.y}px; left: ${a.position.x}px;">
        <div class="clawfi-hover-header">
          ${r?`<img class="clawfi-hover-logo" src="${r}" alt="">`:"<span>🦀</span>"}
          <span class="clawfi-hover-title">ClawFi</span>
          <span class="clawfi-hover-chain">${a.chain}</span>
        </div>
        <div class="clawfi-hover-error">
          No data available for this token
        </div>
      </div>
    `;const{marketData:t,safety:e}=a,o=(e==null?void 0:e.overallRisk)||"low",s=j.getRiskBadge(o),n=D.getDexscreenerUrl(a.chain,a.address),i=D.getDexSwapUrl(a.chain,a.address),l=i.uniswap||i.jupiter||i.pancakeswap||n;return`
    <div class="clawfi-hover-card" style="top: ${a.position.y}px; left: ${a.position.x}px;">
      <div class="clawfi-hover-header">
        ${r?`<img class="clawfi-hover-logo" src="${r}" alt="">`:"<span>🦀</span>"}
        <span class="clawfi-hover-title">ClawFi</span>
        <span class="clawfi-hover-chain">${a.chain}</span>
      </div>
      
      <div class="clawfi-hover-body">
        <div class="clawfi-hover-address" data-copy="${a.address}">
          <span>${a.address.slice(0,8)}...${a.address.slice(-6)}</span>
          <span class="clawfi-hover-copy">📋</span>
        </div>
        
        <div class="clawfi-hover-grid">
          <div class="clawfi-hover-stat">
            <div class="clawfi-hover-stat-label">Price</div>
            <div class="clawfi-hover-stat-value">$${t.priceUsd<.01?t.priceUsd.toExponential(2):t.priceUsd.toFixed(4)}</div>
            <div class="clawfi-hover-stat-sub ${t.priceChange24h>=0?"positive":"negative"}">
              ${t.priceChange24h>=0?"+":""}${t.priceChange24h.toFixed(2)}%
            </div>
          </div>
          
          <div class="clawfi-hover-stat">
            <div class="clawfi-hover-stat-label">Liquidity</div>
            <div class="clawfi-hover-stat-value">$${E(t.liquidity)}</div>
            <div class="clawfi-hover-stat-sub" style="color: rgba(255,255,255,0.5);">${t.dex}</div>
          </div>
          
          <div class="clawfi-hover-stat">
            <div class="clawfi-hover-stat-label">Volume 24h</div>
            <div class="clawfi-hover-stat-value">$${E(t.volume24h)}</div>
            <div class="clawfi-hover-stat-sub" style="color: rgba(255,255,255,0.5);">${t.txns24h.buys}↑ ${t.txns24h.sells}↓</div>
          </div>
          
          <div class="clawfi-hover-stat">
            <div class="clawfi-hover-stat-label">MCap</div>
            <div class="clawfi-hover-stat-value">${t.marketCap?"$"+E(t.marketCap):"N/A"}</div>
          </div>
        </div>
        
        <div class="clawfi-hover-risk ${o}">
          <span class="clawfi-hover-risk-dot"></span>
          <span class="clawfi-hover-risk-text">${s.text}</span>
          <span class="clawfi-hover-risk-score">${(e==null?void 0:e.riskScore)||0}/100</span>
        </div>
        
        <div class="clawfi-hover-actions">
          <a class="clawfi-hover-btn" href="${n}" target="_blank">📊 Chart</a>
          <a class="clawfi-hover-btn primary" href="${l}" target="_blank">💱 Swap</a>
        </div>
      </div>
    </div>
  `}function qe(){$||($=document.createElement("div"),$.id="clawfi-hover-card-host",document.body.appendChild($),v=$.attachShadow({mode:"closed"}))}async function we(a,r,t,e){if(qe(),!v)return;const o=window.innerWidth,s=window.innerHeight;let n=t+10,i=e+10;n+M>o-20&&(n=t-M-10),i+ge>s-20&&(i=s-ge-20),m={visible:!0,loading:!0,address:a,chain:r,marketData:null,safety:null,position:{x:n,y:i}},v.innerHTML=`
    <style>${q()}</style>
    ${R(m)}
  `;try{const[l,d]=await Promise.all([D.getMarketData(a,r),D.getTokenSafety(a,r)]);m&&m.address===a&&(m.loading=!1,m.marketData=l,m.safety=d,v.innerHTML=`
        <style>${q()}</style>
        ${R(m)}
      `,Ee())}catch(l){console.error("[ClawFi HoverCard] Error fetching data:",l),m&&m.address===a&&(m.loading=!1,v.innerHTML=`
        <style>${q()}</style>
        ${R(m)}
      `)}}function ke(){$&&($.remove(),$=null,v=null),m=null}function Ee(){if(!v)return;const a=v.querySelector("[data-copy]");a==null||a.addEventListener("click",async()=>{const t=a.getAttribute("data-copy");if(t)try{await navigator.clipboard.writeText(t);const e=a.querySelector(".clawfi-hover-copy");e&&(e.textContent="✓",setTimeout(()=>{e.textContent="📋"},1e3))}catch(e){console.error("[ClawFi] Copy failed:",e)}});const r=v.querySelector(".clawfi-hover-card");r==null||r.addEventListener("mouseenter",()=>{L&&(clearTimeout(L),L=null)}),r==null||r.addEventListener("mouseleave",()=>{L=setTimeout(ke,ye)})}function Re(){const a=window.location.href.toLowerCase();if(a.includes("solscan.io")||a.includes("pump.fun")||a.includes("jupiter"))return"solana";if(a.includes("basescan")||a.includes("/base/")||a.includes("clanker"))return"base";if(a.includes("arbiscan")||a.includes("/arbitrum/"))return"arbitrum";if(a.includes("bscscan")||a.includes("/bsc/")||a.includes("four.meme")||a.includes("pancakeswap"))return"bsc";if(a.includes("polygonscan")||a.includes("/polygon/"))return"polygon";if(a.includes("dexscreener.com")){const r=a.match(/dexscreener\.com\/([^\/]+)/);if(r){const t=r[1];return t==="ethereum"||t==="eth"?"ethereum":t==="base"?"base":t==="arbitrum"?"arbitrum":t==="bsc"?"bsc":t==="solana"?"solana":t}}return"ethereum"}function je(a){const r=a.target,t=r.textContent||r.innerText||"",e=t.match(N);if(e){const s=e[0],n=Re();b&&clearTimeout(b),b=setTimeout(()=>{we(s,n,a.clientX,a.clientY)},me);return}const o=t.match(G);if(o&&o[0].length>=32&&o[0].length<=44){const s=o[0];b&&clearTimeout(b),b=setTimeout(()=>{we(s,"solana",a.clientX,a.clientY)},me)}}function Me(){b&&(clearTimeout(b),b=null),L=setTimeout(ke,ye)}function Be(){document.addEventListener("mouseover",a=>{const r=a.target;if(r.closest("#clawfi-hover-card-host"))return;const t=r.textContent||"";(N.test(t)||G.test(t))&&je(a)}),document.addEventListener("mouseout",a=>{const r=a.target;if(r.closest("#clawfi-hover-card-host"))return;const t=r.textContent||"";(N.test(t)||G.test(t))&&Me()}),console.log("[ClawFi] Hover cards initialized")}export{Be as i,j as t,D as u};
